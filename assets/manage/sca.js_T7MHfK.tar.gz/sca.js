/**
 * 
 * 主题设置开关JS
 * Update 12/08/2021
 * 
**/

//自定义Gravatar
  $(document).ready(function(){
var cur = "";
$('#Gravatar-0-6').change(function(){
    var a=$(this).children('option:selected').val();
    
    if(a=='7'){
        $("#typecho-option-item-GravatarUrl-6").show();
    }else{
        $("#typecho-option-item-GravatarUrl-6").hide();
    }
})
var options=$("#Gravatar-0-6 option:selected").val();
if(options !== '7'){
$("#typecho-option-item-GravatarUrl-6").hide();
}
//自定义储存

	     $(document).ready(function(){
$('#Assets-0-8').change(function(){
var a1=$(this).children('option:selected').val();

if(a1=='3'){
    $("#typecho-option-item-Assets_Custom-8").show();
}
else{
$("#typecho-option-item-Assets_Custom-8").hide();
}
})
var options1=$("#Assets-0-8 option:selected").val();
if(options1 !== '3'){
$("#typecho-option-item-Assets_Custom-8").hide();
}

})


//文章置顶

	     $(document).ready(function(){

$('#Sticky-0-17').change(function(){
var a2=$(this).children('option:selected').val();

if(a2=='1'){
     $("#typecho-option-item-sticky_cids-17").show();
    $("#typecho-option-item-sticky_html-18").show();
}
else{
$("#typecho-option-item-sticky_cids-17").hide();
    $("#typecho-option-item-sticky_html-18").hide();
}
})
var options2=$("#Sticky-0-17 option:selected").val();
if(options2 !== '1'){
$("#typecho-option-item-sticky_cids-17").hide();
    $("#typecho-option-item-sticky_html-18").hide();
}
})



//文章展现样式



$(document).ready(function(){
	         
$('#Article_forma-0-20').change(function(){
var a3=$(this).children('option:selected').val();
if(a3 == '1'){
    //简洁图文
$("#typecho-option-item-Article_forma_pic-21").show();
$("#typecho-option-item-Article_time-22").show();
   //图底文字
$("#typecho-option-item-Article_forma_pic2-23").hide();
$("#typecho-option-item-Article_time2-24").hide();   
//纯文字2
$("#typecho-option-item-Article_time3-20").hide();
}
else if(a3=='3'){
      //图底文字
$("#typecho-option-item-Article_forma_pic2-23").show();
$("#typecho-option-item-Article_time2-24").show();    
     //简洁图文
$("#typecho-option-item-Article_forma_pic-21").hide();
$("#typecho-option-item-Article_time-22").hide();
//纯文字2
$("#typecho-option-item-Article_time3-20").hide();
}
else if(a3=='4'){
    //纯文字2
$("#typecho-option-item-Article_time3-20").show();  
      //图底文字
$("#typecho-option-item-Article_forma_pic2-23").hide();
$("#typecho-option-item-Article_time2-24").hide();    
     //简洁图文
$("#typecho-option-item-Article_forma_pic-21").hide();
$("#typecho-option-item-Article_time-22").hide();
}
else{
     //简洁图文
$("#typecho-option-item-Article_forma_pic-21").hide();
$("#typecho-option-item-Article_time-22").hide();
   //图底文字
$("#typecho-option-item-Article_forma_pic2-23").hide();
$("#typecho-option-item-Article_time2-24").hide();   
//纯文字2
$("#typecho-option-item-Article_time3-20").hide();
}
})
var options3=$("#Article_forma-0-20 option:selected").val();
if(options3 !== '1'){
     //简洁图文
$("#typecho-option-item-Article_forma_pic-21").hide();
$("#typecho-option-item-Article_time-22").hide();


}
if(options3 !== '3'){
   //图底文字
$("#typecho-option-item-Article_forma_pic2-23").hide();
$("#typecho-option-item-Article_time2-24").hide();   

}
if(options3 !== '4'){

//纯文字2
$("#typecho-option-item-Article_time3-20").hide();
}


})


//DNS预解析

	     $(document).ready(function(){

$('#DNSYJX-0-61').change(function(){
var a4=$(this).children('option:selected').val();

if(a4=='1'){
     $("#typecho-option-item-DNSADDRESS1-61").show();
    $("#typecho-option-item-DNSADDRESS2-62").show();
    $("#typecho-option-item-DNSADDRESS3-63").show();
}
else{
$("#typecho-option-item-DNSADDRESS1-61").hide();
    $("#typecho-option-item-DNSADDRESS2-62").hide();
    $("#typecho-option-item-DNSADDRESS3-63").hide();
}
})
var options4=$("#DNSYJX-0-61 option:selected").val();
if(options4 !== '1'){
$("#typecho-option-item-DNSADDRESS1-61").hide();
    $("#typecho-option-item-DNSADDRESS2-62").hide();
    $("#typecho-option-item-DNSADDRESS3-63").hide();
}
})




//幻灯片

	     $(document).ready(function(){

$('#Slidersss-0-13').change(function(){
var a5=$(this).children('option:selected').val();

if(a5=='1'){
    $("#typecho-option-item-SliderIndexs-13").show();
    $("#typecho-option-item-SliderOthers-14").show();
    $("#typecho-option-item-SliderPics-15").show();
}
else{
$("#typecho-option-item-SliderIndexs-13").hide();
    $("#typecho-option-item-SliderOthers-14").hide();
    $("#typecho-option-item-SliderPics-15").hide();
}
})
var options5=$("#Slidersss-0-13 option:selected").val();
if(options5 !== '1'){
$("#typecho-option-item-SliderIndexs-13").hide();
    $("#typecho-option-item-SliderIndexs-14").hide();
    $("#typecho-option-item-SliderIndexs-15").hide();
}
})

//弹窗

	     $(document).ready(function(){

$('#Popup-0-92').change(function(){
var a6=$(this).children('option:selected').val();

if(a6=='1'){
$("#typecho-option-item-PopupText-92").show();
    $("#typecho-option-item-PopupUrl-93").show();
}
else{
$("#typecho-option-item-PopupText-92").hide();
    $("#typecho-option-item-PopupUrl-93").hide();
}
})
var options6=$("#Slidersss-0-13 option:selected").val();
if(options6 !== '1'){
$("#typecho-option-item-PopupText-92").hide();
    $("#typecho-option-item-PopupUrl-93").hide();
}
})

//友链
$(document).ready(function(){
$('#FriendLinkChoose-0-11').change(function(){
var a7=$(this).children('option:selected').val();

if(a7=='1'){
$("#typecho-option-item-FriendLink-11").show();
}
else{
$("#typecho-option-item-FriendLink-11").hide();
}
})
var options7=$("#Slidersss-0-13 option:selected").val();
if(options7 !== '1'){
$("#typecho-option-item-FriendLink-11").hide();
}
})

//其他设置
//返回顶部
$(document).ready(function(){
$('#Top-0-105').change(function(){
var a8=$(this).children('option:selected').val();

if(a8=='1'){
$("#typecho-option-item-TopSrc-105").show();
}
else{
$("#typecho-option-item-TopSrc-105").hide();
}
})
var options8=$("#Top-0-105 option:selected").val();
if(options8 !== '1'){
$("#typecho-option-item-TopSrc-105").hide();
}
})

//翻译
$(document).ready(function(){
$('#Translate-0-103').change(function(){
var a9=$(this).children('option:selected').val();

if(a9=='1'){
$("#typecho-option-item-TranslateLanguage-103").show();
}
else{
$("#typecho-option-item-TranslateLanguage-103").hide();
}
})
var options9=$("#Translate-0-103 option:selected").val();
if(options9 !== '1'){
$("#typecho-option-item-TranslateLanguage-103").hide();
}
})

//缓存
$(document).ready(function(){
$('#Cache-0-87').change(function(){
var a10=$(this).children('option:selected').val();

if(a10=='1'){
$("#typecho-option-item-cache_dir-87").show();
$("#typecho-option-item-cache_timeout-88").show();
}
else{
$("#typecho-option-item-cache_dir-87").hide();
$("#typecho-option-item-cache_timeout-88").hide();

}
})
var options10=$("#Cache-0-87 option:selected").val();
if(options10 !== '1'){
$("#typecho-option-item-cache_dir-87").hide();
$("#typecho-option-item-cache_timeout-88").hide();


}
})
})