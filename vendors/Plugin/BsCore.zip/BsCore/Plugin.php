<?php
namespace TypechoPlugin\BsCore;
use Typecho\Plugin\PluginInterface;
use Typecho\Widget\Helper\Form;
use Typecho\Widget\Helper\Form\Element\Text;
use Widget\Options;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}
  
/**
 * BearSimple主题核心插件，针对Typecho1.2 Beta及以上版本，启用后无需其他设置，<a style="color:red">非Typecho1.2 Beta及以上版本请勿安装</a>
 *
 * @package BsCore
 * @author WhiteBear
 * @version 1.0.0
 * @link https://www.coder-bear.com/
 */
class Plugin implements PluginInterface
{
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     */
    public static function activate()
    {
    //代码高亮 
    \Typecho\Plugin::factory('Widget_Archive')->header = __CLASS__ .'::codehightlight_headlink';
    \Typecho\Plugin::factory('Widget_Archive')->footer = __CLASS__ .'::codehightlight_footlink';
    //缓存 
    \Typecho\Plugin::factory('index.php')->begin = __CLASS__ .'::cache_getCache';
    \Typecho\Plugin::factory('index.php')->end = __CLASS__ .'::cache_setCache';
    //验证->无感验证
    \Typecho\Plugin::factory('Widget_Feedback')->comment = __CLASS__ . '::beforeComment';
    \Typecho\Plugin::factory('Widget_Archive')->beforeRender = __CLASS__ . '::initCaptcha';
    //评论检验
    \Typecho\Plugin::factory('Widget_Feedback')->comment = __CLASS__ . '::filter';

    //编辑器美化->传统编辑器
    \Typecho\Plugin::factory('admin/write-post.php')->bottom = __CLASS__ . '::button';
    \Typecho\Plugin::factory('admin/write-page.php')->bottom = __CLASS__ . '::button';
    //音乐歌单
    \Typecho\Plugin::factory('Widget_Archive')->header = __CLASS__ . '::header';
    \Typecho\Plugin::factory('Widget_Archive')->footer = __CLASS__ . '::footer';
    //回复可见处理
    \Typecho\Plugin::factory('Widget_Abstract_Contents')->excerptEx = __CLASS__ . '::one';
    \Typecho\Plugin::factory('Widget_Abstract_Contents')->contentEx = __CLASS__ . '::one';
    //Vaptcha
    \Typecho\Plugin::factory('Widget_Archive')->header = __CLASS__ . '::vaptcha_header';
    \Typecho\Plugin::factory('Widget_Archive')->footer = __CLASS__ . '::vaptcha_footer';
    return '启用成功，使用Bearsimple主题时本插件务必保持开启状态！';
    }

    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     */
    public static function deactivate()
    {
      return '禁用成功，使用Bearsimple主题时本插件务必保持开启状态！';
    }

    /**
     * 获取插件配置面板
     *
     * @param Form $form 配置面板
     */
    public static function config(Form $form)
    {
       
    }

    /**
     * 个人用户的配置面板
     *
     * @param Form $form
     */
    public static function personalConfig(Form $form)
    {
    }

    /**
     * 代码高亮 Codehightlight
     * Date:09/10/2021
     *
     * @access public
     * @return void
     */
     
    public static function codehightlight_headlink()
    {
       $options = Options::alloc();
    if ($options->Codehightlight == '1'){
        $dir = $options->themeUrl.'/';
   
    
        $style = Options::alloc()->code_style;
        if(empty($style)){
            $style = 'coy.css';
        }
        else{
       $style = Options::alloc()->code_style;
        }
        $cssUrl = $dir.'modules/codehightlight/static/styles/' . $style;
        echo '<link rel="stylesheet" type="text/css" href="' . $cssUrl . '" />';
    }
    }
    
    public static function codehightlight_footlink()
    {
       $options = Options::alloc();
       if ($options->Codehightlight == '1'){
        $dir = $options->themeUrl.'/';
  
    
         $jsUrl = $dir.'modules/codehightlight/static/prism.js';
        $jsUrl_clipboard = $dir.'modules/codehightlight/static/clipboard.min.js';
        $showLineNumber = Options::alloc()->showLineNumber;
        if ($showLineNumber == '1') {
            echo <<<HTML
<script type="text/javascript">
	(function(){
		var pres = document.querySelectorAll('pre');
		var lineNumberClassName = 'line-numbers';
		pres.forEach(function (item, index) {
			item.className = item.className == '' ? lineNumberClassName : item.className + ' ' + lineNumberClassName;
		});
	})();
</script>
<script type="text/javascript">
$(document).on('pjax:complete', function() {
if (typeof Prism !== 'undefined') {
var pres = document.getElementsByTagName('pre');
                for (var i = 0; i < pres.length; i++){
                    if (pres[i].getElementsByTagName('code').length > 0)
                        pres[i].className  = 'line-numbers';}
Prism.highlightAll(true,null);}
});
</script>


HTML;
        }
        echo <<<HTML
<script type="text/javascript" src="{$jsUrl_clipboard}"></script>
<script type="text/javascript" src="{$jsUrl}"></script>

HTML;
    }
    }
  
    /**
     * 缓存 Cache
     * Date:09/10/2021
     *
     * @access public
     * @return void
     */ 
     
     public static function cache_getCache(){
         $options = Options::alloc();
         if ($options->Cache == '1'){
        $req = \Typecho\Request::getInstance();
        $url = $req->getRequestUri();


        if(!$req->isGet()){
            return;
        }
        if(strstr($url,'/action/') !== false || strstr($url,'/admin/') !== false){
            
            return;
        }

        $hash = md5($url);

        @$settings = Options::alloc();
        if(!$settings) return;


        $cache_timeout = intval($settings->cache_timeout);

        $cache_root = $settings->cache_dir;
        if(strstr($cache_root, '/') !== 0 ){
            $cache_root = __TYPECHO_ROOT_DIR__.'/usr/'.$cache_root;
        }

        if($cache_timeout <= 0){
            $cache_timeout = 60; //1min
        }

        $file = self::hash2dir($hash,$cache_root).$hash.".gz";
        if(file_exists($file)){
            $filetime = filemtime($file);
            if($filetime !== false && time() - $filetime < $cache_timeout){
                $fh = fopen($file, "rb");
                $content = fread($fh,filesize ($file));
                fclose($fh);
                $html = gzuncompress($content);
                echo $html;
                exit(0);
            }
        }else{
        
        }
    }
}

    public static function cache_setCache(){
        $options = Options::alloc();
         if ($options->Cache == '1'){
        $req = \Typecho\Request::getInstance();
        $url = $req->getRequestUri();
        
        if(!$req->isGet()){ #仅处理GET请求
            return;
        }
        if(strstr($url,'/action/') !== false || strstr($url,'/admin/') !== false){
            #排除action接口,这个一般是特殊接口,所以不需要缓存
            return;
        }

        @$settings = Options::alloc();
        if(!$settings) return;
        $cache_root = $settings->cache_dir;
        if(strstr($cache_root, '/') !== 0 ){
            $cache_root = __TYPECHO_ROOT_DIR__.'/usr/'.$cache_root;
        }

        $hash = md5($url);
        $file = self::hash2dir($hash,$cache_root).$hash.".gz";
        $dir = dirname($file);

        if(!file_exists($dir)){
            $ret = mkdir($dir,0777,true);
            if(!$ret){
                return;
            }
        }

        $html = ob_get_contents();
        $html_gz = gzcompress($html);
        $fp = fopen($file, 'w');
        fwrite($fp, $html_gz);
        fclose($fp);
    }
}

    private static function hash2dir($hash,$base_dir=""){
        $dir="";
        for($i = 0; $i < strlen($hash) ; $i+=2){
            $dir = $dir."/".substr($hash, $i, 2);
        }
        return rtrim($base_dir,'/').$dir.'/';
    }

    /**
     * 无感验证 SimpleCommentCaptcha
     * Date:09/10/2021
     *
     * @access public
     * @return void
     */ 

     protected static $session_key_prefix = 'SimpleCommentCaptcha_Plugin_';
    protected static $form_field_name = 'SimpleCommentCaptcha_Plugin_x';
    protected static $calculation_param_x;
    protected static $calculation_param_y;
    protected static $calculation_res;
    protected static $calculation_param_x_start;
    protected static $calculation_param_x_end;
     /**
     * 评论数据入库前校验
     *
     * @param array $comment
     * @param Widget_Archive $archive
     * @return void
     */
    public static function beforeComment($comment, $archive) {
        $options = Options::alloc();
    if ($options->VerifyChoose == '4'){
        $submit_x = (int) $archive->request->get(self::$form_field_name);
        $banned_ip_list = array_map(
            'trim',
            explode("\n", self::getFromOptions('banned_ip_list'))
        );

        if (in_array($comment['ip'], $banned_ip_list)) {
            // ip 在黑名单内
            throw new \Typecho\Widget\Exception(_t('您所在 ip 已被禁止评论操作！'));
        }

        if (
            $submit_x
            && self::getFromSession('x')
            && self::getFromSession('x') === $submit_x
        ) {
            // 校验成功
            self::removeFromSession('x');

            $spam_ip_action = self::getFromOptions('spam_ip_action');
            if ($spam_ip_action === '2') {
                // 若不处理存在垃圾评论的 ip ，直接返回
                return $comment;
            }

            if (in_array($comment['ip'], self::getCommentedTrashIpList())) {
                // ip 存在垃圾留言记录
                switch ($spam_ip_action) {
                    case '0':
                        $comment['status'] = 'waiting';
                        self::storeInSession(
                            'message',
                            _t('您的留言已进入待审核列表！')
                        );
                        break;
                    case '1':
                        $comment['status'] = 'spam';
                        break;
                }
            }
        } else {
            // 校验失败
            switch (self::getFromOptions('banned_action')) {
                case '0':
                    $comment['status'] = 'waiting';
                    self::storeInSession(
                        'message',
                        _t('您的留言已进入待审核列表！')
                    );
                    break;
                case '1':
                    $comment['status'] = 'spam';
                    break;
                case '2':
                    throw new \Typecho\Widget\Exception(_t('您的评论操作不合法！'));
            }
        }

        return $comment;
    }
}
    /**
     * 验证数据初始化、存储会话数据
     *
     * @param Widget_Archive $archive
     * @return void
     */
    public static function initCaptcha($archive)
    {
         $options = Options::alloc();
    if ($options->VerifyChoose == '4'){
        // 只在文章页和独立页面初始化验证数据（其他地方没有评论）
        if (!$archive->is('single') && !$archive->is('page')) {
            return ;
        }

        $start_num = 1000 * self::getFromOptions('protection_level');
        $end_num = $start_num * 10 - 1;
        self::$calculation_param_x_start = $start_num;
        self::$calculation_param_x_end = $end_num;
        self::$calculation_param_x = rand($start_num, $end_num);
        self::$calculation_param_y = rand(1, 1000) + 1;
        self::$calculation_res = self::calculateFunction(
            self::$calculation_param_x,
            self::$calculation_param_y
        );

        self::storeInSession('x', self::$calculation_param_x);
        self::storeInSession('y', self::$calculation_param_y);
        self::storeInSession('res', self::$calculation_res);
    }
}
    /**
     * 输出验证码所需表单内容和运算数据、过程
     * 需要在主题的评论区域（表单内部）调用
     *
     * @return void
     */
    public static function outputSimpleCommentCaptchaField($t)
    {
        $options = Options::alloc();
    if ($options->VerifyChoose == '4'){
        // 只在文章页和独立页面初始化验证数据（其他地方没有评论）
        if (!$t->is('single') && !$t->is('page')) {
            return ;
        }
        $message = self::getFromSession('message');
        $message = $message ? $message : '';

        if (self::getFromOptions('alert_message') === '0') {
            // 若关闭待审核 alert 提醒
            $message = '';
        }

        echo '<input name="'.self::$form_field_name.'" value="" hidden>';
        echo '<script> document.addEventListener("readystatechange",function(){'
            . '  if (document.readyState !== "interactive") {return;}'
            . '  setTimeout(function() {'
            . '    var SCCF_startX = ' . self::$calculation_param_x_start . ';'
            . '    var SCCF_endX = ' . self::$calculation_param_x_end .';'
            . '    var SCCF_res = ' . self::$calculation_res . ';'
            . '    var SCCF_paramY= ' . self::$calculation_param_y. ';'
            . '    var SCCF_tmpRes = 0;'
            . '    var SCCF_midM = 0;'
            . '    for (var i = SCCF_startX; i <= SCCF_endX; i++) {'
            . '      SCCF_midM = Math.abs('
            . '        Math.sin((i % Math.PI) * ((i + 2) % Math.PI) * 120)'
            . '      ) * 111;'
            . '      SCCF_midM *= 10000000;'
            . '      SCCF_tmpRes = Math.log(SCCF_midM) / Math.log(SCCF_paramY);'
            . '      if (Math.abs(SCCF_tmpRes - SCCF_res) < 0.0000000001) {'
            . '        var inputElement = document.getElementsByName("'
            .            self::$form_field_name . '")[0];'
            . 'inputElement.value = i;'
            . 'break;'
            . '}'
            . '}'
            . '},'.intval(self::getFromOptions('delay_time')) * 1000 .');'
            . 'var SCCF_message = "'.$message.'";'
            . 'if (SCCF_message) {alert(SCCF_message);}'
            . '});</script>';
        self::removeFromSession('message');
    }
}
    /**
     * 计算算子
     *
     * @param int $x 因子 x
     * @param int $y 因子 y
     * @return double 计算结果
     */
    public static function calculateFunction($x, $y)
    {
        $mid_num = abs(sin(fmod($x, pi()) * fmod($x + 2, pi()) * 120)) * 111;
        self::storeInSession('x', $x);
        return log($mid_num * 10000000, $y);
    }

    /**
     * 存储一项数据到会话
     *
     * @param string $name 会话数据项名称
     * @param mixed $value 会话数据项值
     * @return void
     */
    public static function storeInSession($name, $value)
    {
        self::ensureSessionStarted();
        $_SESSION[self::$session_key_prefix . $name] = $value;
    }

    /**
     * 从会话中获取一项数据
     *
     * @param string $name
     * @param mixed $default
     * @return void
     */
    public static function getFromSession($name, $default = null)
    {
        self::ensureSessionStarted();
        $key = self::$session_key_prefix . $name;
        if (isset($_SESSION[$key])) {
            return $_SESSION[$key];
        }
        return $default;
    }

    /**
     * 从会话中删除一项数据
     *
     * @param string $name 会话数据项名称
     * @return void
     */
    public static function removeFromSession($name)
    {
        self::ensureSessionStarted();
        unset($_SESSION[self::$session_key_prefix . $name]);
    }

    /**
     * 确保 session 开启
     *
     * @return void
     */
    public static function ensureSessionStarted()
    {
        if (!session_id()) {
            session_start();
        }
    }

    /**
     * 获取插件设置结果
     *
     * @param string $name 设置项名称
     * @return string
     */
    public static function getFromOptions($name)
    {
        return Options::alloc()->{$name};
    }

    /**
     * 获取存在垃圾评论的 ip 列表
     *
     * @return array
     */
    public static function getCommentedTrashIpList()
    {
        $db = Typecho_Db::get();
        $ip_list = $db->fetchAll(
            $db->select('ip')->from('table.comments')
                ->where('status = ?', 'spam')
        );
        return array_column($ip_list, 'ip');
    }
    
     /**
     * 评论检验 CheckSec
     * Date:09/10/2021
     *
     * @access public
     * @return void
     */ 
     public static function xsscheck($text)
{
    $xsscheck = false;
    $list = array(
        '/onabort/is',
        '/onblur/is',
        '/onchange/is',
        '/onclick/is',
        '/ondblclick/is',
        '/onerror/is',
        '/onfocus/is',
        '/onkeydown/is',
        '/onkeypress/is',
        '/onkeyup/is',
        '/onload/is',
        '/onmousedown/is',
        '/onmousemove/is',
        '/onmouseout/is',
        '/onmouseover/is',
        '/onmouseup/is',
        '/onreset/is',
        '/onresize/is',
        '/onselect/is',
        '/onsubmit/is',
        '/onunload/is',
        '/eval/is',
        '/ascript:/is',
        '/style=/is',
        '/width=/is',
        '/width:/is',
        '/height=/is',
        '/height:/is',
        '/src=/is',
    );
    if (strip_tags($text)) {
        for ($i = 0; $i < count($list); $i++) {
            if (preg_match($list[$i], $text) > 0) {
                $xsscheck = true;
                break;
            }
        }
    } else {
        $xsscheck = true;
    };
    return $xsscheck;
}

/**
    * PHP获取字符串中英文混合长度 
    */
    public static function strLength($str){        
        preg_match_all('/./us', $str, $match);
        return count($match[0]);  // 输出9
    }
        

    /**
     * 检查$str中是否含有$words_str中的词汇
     * 
     */
	public static function check_in($words_str, $str)
	{
		$words = explode("\n", $words_str);
		if (empty($words)) {
			return false;
		}
		foreach ($words as $word) {
            if (false !== strpos($str, trim($word))) {
                return true;
            }
		}
		return false;
	}

    /**
     * 检查$ip中是否在$words_ip的IP段中
     * 
     */
	public static function check_ip($words_ip, $ip)
	{
		$words = explode("\n", $words_ip);
		if (empty($words)) {
			return false;
		}
		foreach ($words as $word) {
			$word = trim($word);
			if (false !== strpos($word, '*')) {
				$word = "/^".str_replace('*', '\d{1,3}', $word)."$/";
				if (preg_match($word, $ip)) {
					return true;
				}
			} else {
				if (false !== strpos($ip, $word)) {
					return true;
				}
			}
		}
		return false;
	}
	
 public static function filter($comment,$post){
 $options = Options::alloc();
         if (strlen(trim(preg_replace('/\xc2\xa0/',' ',$comment['text']))) == 0) {
			\Typecho\Cookie::set('__typecho_remember_text', $comment['text']);
			throw new \Typecho\Widget\Exception("抱歉，系统检测到您的评论内容只有空格，请返回修改后再试。");
            }
            
        if(Plugin::xsscheck($comment['text'])) {
			\Typecho\Cookie::set('__typecho_remember_text', $comment['text']);
			throw new \Typecho\Widget\Exception("抱歉，系统检测到您的评论包含危险内容，请返回修改后再试。");
        }
        
        if (!empty($options->BearSpam_IP)) {
			if (Plugin::check_ip($options->BearSpam_IP, $comment['ip'])) {
			throw new \Typecho\Widget\Exception("抱歉，系统检测到您的IP处于屏蔽范围内，已拦截本条评论。");
			  \Typecho\Cookie::set('__typecho_remember_text', $comment['text']);
			}

            
        }
		if (!empty($options->BearSpam_EMAIL)) {
			if (Plugin::check_in($options->BearSpam_EMAIL, $comment['mail'])) {
				throw new \Typecho\Widget\Exception("抱歉，系统检测到您的邮箱处于屏蔽范围内，已拦截本条评论。");
				  \Typecho\Cookie::set('__typecho_remember_text', $comment['text']);
			}
		}
		
			if (!empty($options->BearSpam_NAME)) {
			if (Plugin::check_in($options->BearSpam_NAME, $comment['author'])) {
				throw new \Typecho\Widget\Exception("抱歉，系统检测到您的昵称存在敏感禁止词汇，已拦截本条评论。");
				  \Typecho\Cookie::set('__typecho_remember_text', $comment['text']);
			}
		}
		
		if (!empty($options->BearSpam_URL)) {
			if (Plugin::check_in($options->BearSpam_URL, $comment['url'])) {
			    			throw new \Typecho\Widget\Exception("抱歉，系统检测到您的网址处于屏蔽范围内，已拦截本条评论。");
			\Typecho\Cookie::set('__typecho_remember_text', $comment['text']);
			}
			}
			
			if (!empty($options->BearSpam_ArticleTitle)&& $options->BearSpam_ArticleTitle == "1") {
			$db = \Typecho\Db::get();
            // 获取评论所在文章
            $pot = $db->fetchRow($db->select('title')->from('table.contents')->where('cid = ?', $comment['cid']));        
            if(strstr($comment['text'], $pot['title'])){
                		throw new \Typecho\Widget\Exception("抱歉，系统检测到您的评论内容疑似存在灌水内容，已自动拦截。");
\Typecho\Cookie::set('__typecho_remember_text', $comment['text']);
			}
			}
			
			if (!empty($options->BearSpam_NAMEMIN)) {    
            if(Plugin::strLength($comment['author']) < $options->BearSpam_NAMEMIN){

			throw new \Typecho\Widget\Exception("抱歉，系统检测到您的评论昵称过短，已自动拦截。");
			\Typecho\Cookie::set('__typecho_remember_text', $comment['text']);
			}
			}
			
			if (!empty($options->BearSpam_NAMEMAX)) {    
            if (Plugin::strLength($comment['author'] > $options->BearSpam_NAMEMAX)) {
                throw new \Typecho\Widget\Exception("抱歉，系统检测到您的评论昵称过长，已自动拦截。");
			\Typecho\Cookie::set('__typecho_remember_text', $comment['text']);
			}}
			
			if (!empty($options->BearSpam_NAMEURL)&& $options->BearSpam_NAMEURL == "1") {    
            if (preg_match(" /^((https?|ftp|news):\/\/)?([a-z]([a-z0-9\-]*[\.。])+([a-z]{2}|aero|arpa|biz|com|coop|edu|gov|info|int|jobs|mil|museum|name|nato|net|org|pro|travel)|(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5]))(\/[a-z0-9_\-\.~]+)*(\/([a-z0-9_\-\.]*)(\?[a-z0-9+_\-\.%=&]*)?)?(#[a-z][a-z0-9_]*)?$/ ", $comment['author']) > 0) {
			                throw new \Typecho\Widget\Exception("抱歉，系统检测到您的评论昵称异常，已自动拦截。");
			\Typecho\Cookie::set('__typecho_remember_text', $comment['text']);
			}}
			
			if (!empty($options->BearSpam_Chinese)&& $options->BearSpam_Chinese == "1") {    
            if (preg_match("/[\x{4e00}-\x{9fa5}]/u", $comment['text']) == 0) {
			throw new \Typecho\Widget\Exception("抱歉，系统检测到您的评论内容不包含中文，已自动拦截。");
			\Typecho\Cookie::set('__typecho_remember_text', $comment['text']);
			}}
			
			if (!empty($options->BearSpam_MIN)) {    
            if(Plugin::strLength($comment['text']) < $options->BearSpam_MIN){         
				throw new \Typecho\Widget\Exception("抱歉，系统检测到您的评论内容字数过少，已自动拦截。");
			\Typecho\Cookie::set('__typecho_remember_text', $comment['text']);
			}}
			
			if (!empty($options->BearSpam_Words)) {    
            if (Plugin::check_in($options->BearSpam_Words, $comment['text'])) { 
	throw new \Typecho\Widget\Exception("抱歉，系统检测到您的评论内容包含敏感禁止词汇，已自动拦截。");
			\Typecho\Cookie::set('__typecho_remember_text', $comment['text']);
			}
					    
			}
            \Typecho\Cookie::delete('__typecho_remember_text');
        return $comment;
 }
 
    
    /**
     * 编辑器美化 传统编辑器
     * Date:09/10/2021
     *
     * @access public
     * @return void
     */ 
     public static function button(){
         $options = Options::alloc();
		?><style>.wmd-button-row {
    height: auto;
}</style>

		<script> 
          $(document).ready(function(){
          	$('#wmd-button-row').append('<li class="wmd-button" id="wmd-hfkj-button" title="回复可见"><span style="background: none;margin-top:5px;font-size: large;text-align: center;color: #999999;font-family: serif;"><svg t="1631542611669" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="4626" width="16" height="16"><path d="M850.858667 254.72c103.936 71.68 173.226667 168.362667 173.141333 257.109333 0 165.888-251.989333 365.909333-512 365.909334-80.213333 0-160.426667-19.541333-232.704-51.456l55.04-55.04c53.76 20.565333 113.578667 33.28 177.664 33.28 257.877333 0 438.869333-199.253333 438.869333-292.693334 0-54.357333-56.576-140.117333-152.405333-204.714666zM512 146.346667c69.973333 0 139.093333 13.909333 202.752 37.632l-56.746667 56.746666A509.269333 509.269333 0 0 0 512 219.392C261.461333 219.392 73.130667 415.146667 73.130667 511.829333c0 49.066667 48.213333 123.562667 128.512 185.173334l-52.309334 52.309333C59.221333 679.765333 0 592.042667 0 511.829333 0 345.6 256.085333 146.261333 512 146.261333z" p-id="4627"></path><path d="M675.498667 430.165333A182.869333 182.869333 0 0 1 430.08 675.584zM512 329.130667c17.493333 0 34.474667 2.474667 50.517333 7.082666L336.128 562.346667A183.04 183.04 0 0 1 512 329.130667zM840.192 101.546667a42.666667 42.666667 0 0 1 65.28 54.442666l-4.949333 5.973334-724.053334 724.053333a42.666667 42.666667 0 0 1-65.28-54.442667l4.949334-5.973333L840.192 101.546667z" p-id="4628"></path></svg></span></li>');
				if($('#wmd-button-row').length !== 0){
					$('#wmd-hfkj-button').click(function(){
						var rs = "{bs-hide}隐藏内容{/bs-hide}";
						hfkj(rs);
					})
				}


				function hfkj(tag) {
					var myField;
					if (document.getElementById('text') && document.getElementById('text').type == 'textarea') {
						myField = document.getElementById('text');
					} else {
						return false;
					}
					if (document.selection) {
						myField.focus();
						sel = document.selection.createRange();
						sel.text = tag;
						myField.focus();
					}
					else if (myField.selectionStart || myField.selectionStart == '0') {
						var startPos = myField.selectionStart;
						var endPos = myField.selectionEnd;
						var cursorPos = startPos;
						myField.value = myField.value.substring(0, startPos)
						+ tag
						+ myField.value.substring(endPos, myField.value.length);
						cursorPos += tag.length;
						myField.focus();
						myField.selectionStart = cursorPos;
						myField.selectionEnd = cursorPos;
					} else {
						myField.value += tag;
						myField.focus();
					}
				}

				

			});
</script>

<script> 
          $(document).ready(function(){
          	$('#wmd-button-row').append('<li class="wmd-button" id="wmd-todocheck-button" title="打勾已完成"><span style="background: none;margin-top:5px;font-size: large;text-align: center;color: #999999;font-family: serif;"><svg t="1631543018887" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="5633" width="16" height="16"><path d="M128 85.333333h768a42.666667 42.666667 0 0 1 42.666667 42.666667v768a42.666667 42.666667 0 0 1-42.666667 42.666667H128a42.666667 42.666667 0 0 1-42.666667-42.666667V128a42.666667 42.666667 0 0 1 42.666667-42.666667z m42.666667 85.333334v682.666666h682.666666V170.666667H170.666667z m122.154666 262.869333a21.333333 21.333333 0 0 1 30.165334 0.106667l126.378666 127.296 251.050667-233.877334a21.333333 21.333333 0 0 1 30.165333 1.066667l29.077334 31.210667a21.333333 21.333333 0 0 1-1.066667 30.144L462.165333 665.642667a21.333333 21.333333 0 0 1-29.674666-0.576l-170.048-171.306667a21.333333 21.333333 0 0 1 0.106666-30.165333l30.293334-30.08z" p-id="5634"></path></svg></span></li>');
				if($('#wmd-button-row').length !== 0){
					$('#wmd-todocheck-button').click(function(){
						var rs = "{bs-todo type=true}Todolist已完成的内容{/bs-todo}";
						todocheck(rs);
					})
				}


				function todocheck(tag) {
					var myField;
					if (document.getElementById('text') && document.getElementById('text').type == 'textarea') {
						myField = document.getElementById('text');
					} else {
						return false;
					}
					if (document.selection) {
						myField.focus();
						sel = document.selection.createRange();
						sel.text = tag;
						myField.focus();
					}
					else if (myField.selectionStart || myField.selectionStart == '0') {
						var startPos = myField.selectionStart;
						var endPos = myField.selectionEnd;
						var cursorPos = startPos;
						myField.value = myField.value.substring(0, startPos)
						+ tag
						+ myField.value.substring(endPos, myField.value.length);
						cursorPos += tag.length;
						myField.focus();
						myField.selectionStart = cursorPos;
						myField.selectionEnd = cursorPos;
					} else {
						myField.value += tag;
						myField.focus();
					}
				}
			});
</script>
<script> 
          $(document).ready(function(){
          	$('#wmd-button-row').append('<li class="wmd-button" id="wmd-todonotcheck-button" title="打叉未完成"><span style="background: none;margin-top:5px;font-size: large;text-align: center;color: #999999;font-family: serif;"><svg t="1631543115096" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="7147" width="16" height="16"><path d="M768 102.4H256C168.96 102.4 102.4 168.96 102.4 256v512c0 87.04 66.56 153.6 153.6 153.6h512c87.04 0 153.6-66.56 153.6-153.6V256c0-87.04-66.56-153.6-153.6-153.6z m51.2 665.6c0 30.72-20.48 51.2-51.2 51.2H256c-30.72 0-51.2-20.48-51.2-51.2V256c0-30.72 20.48-51.2 51.2-51.2h512c30.72 0 51.2 20.48 51.2 51.2v512z" p-id="7148"></path></svg></span></li>');
				if($('#wmd-button-row').length !== 0){
					$('#wmd-todonotcheck-button').click(function(){
						var rs = "{bs-todo type=false}Todolist待完成的内容{/bs-todo}";
						todonotcheck(rs);
					})
				}


				function todonotcheck(tag) {
					var myField;
					if (document.getElementById('text') && document.getElementById('text').type == 'textarea') {
						myField = document.getElementById('text');
					} else {
						return false;
					}
					if (document.selection) {
						myField.focus();
						sel = document.selection.createRange();
						sel.text = tag;
						myField.focus();
					}
					else if (myField.selectionStart || myField.selectionStart == '0') {
						var startPos = myField.selectionStart;
						var endPos = myField.selectionEnd;
						var cursorPos = startPos;
						myField.value = myField.value.substring(0, startPos)
						+ tag
						+ myField.value.substring(endPos, myField.value.length);
						cursorPos += tag.length;
						myField.focus();
						myField.selectionStart = cursorPos;
						myField.selectionEnd = cursorPos;
					} else {
						myField.value += tag;
						myField.focus();
					}
				}
			});
</script>
<script> 
          $(document).ready(function(){
          	$('#wmd-button-row').append('<li class="wmd-button" id="wmd-codes-button" title="打叉未完成"><span style="background: none;margin-top:5px;font-size: large;text-align: center;color: #999999;font-family: serif;"><svg t="1632126906909" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2425" width="16" height="16"><path d="M298.900577 778.338974c-7.070023 7.070023-17.974373 7.070023-25.043373 0L20.039405 524.521175c-7.070023-7.070023-7.070023-17.974373 0-25.043373l253.8178-253.8178c7.070023-7.070023 17.974373-7.070023 25.043373 0l27.242458 27.242458c7.070023 7.070023 7.070023 17.974373 0 25.043373L112.089891 512l214.053144 214.053144c7.070023 7.070023 7.070023 17.974373 0 25.043373L298.900577 778.338974zM444.87316 873.098151c-2.726088 9.269108-12.522198 14.702863-21.24486 11.995195l-33.767058-9.269108c-9.250688-2.726088-14.702863-12.522198-11.976776-21.790282l203.148793-703.132108c2.726088-9.269108 12.522198-14.702863 21.24486-11.995195l33.767058 9.269108c9.250688 2.726088 14.702863 12.522198 11.976776 21.790282L444.87316 873.098151zM752.049215 778.338974c-7.070023 7.070023-17.974373 7.070023-25.043373 0l-27.242458-27.242458c-7.070023-7.070023-7.070023-17.974373 0-25.043373l214.053144-214.053144L699.763384 297.946856c-7.070023-7.070023-7.070023-17.974373 0-25.043373l27.242458-27.242458c7.070023-7.070023 17.974373-7.070023 25.043373 0l253.8178 253.8178c7.070023 7.070023 7.070023 17.974373 0 25.043373L752.049215 778.338974z" p-id="2426" fill="#707070"></path></svg></span></li>');
				if($('#wmd-button-row').length !== 0){
					$('#wmd-codes-button').click(function(){
						var rs = "```编程语言\n这里是内容\n```";
						codes(rs);
					})
				}


				function codes(tag) {
					var myField;
					if (document.getElementById('text') && document.getElementById('text').type == 'textarea') {
						myField = document.getElementById('text');
					} else {
						return false;
					}
					if (document.selection) {
						myField.focus();
						sel = document.selection.createRange();
						sel.text = tag;
						myField.focus();
					}
					else if (myField.selectionStart || myField.selectionStart == '0') {
						var startPos = myField.selectionStart;
						var endPos = myField.selectionEnd;
						var cursorPos = startPos;
						myField.value = myField.value.substring(0, startPos)
						+ tag
						+ myField.value.substring(endPos, myField.value.length);
						cursorPos += tag.length;
						myField.focus();
						myField.selectionStart = cursorPos;
						myField.selectionEnd = cursorPos;
					} else {
						myField.value += tag;
						myField.focus();
					}
				}
			});
</script>
<?php
}

     /**
     * 音乐歌单 Music
     * Date:09/10/2021
     *
     * @access public
     * @return void
     */ 
     public static function header(){
         $options = Options::alloc();
    if ($options->music == '1'){
        $cssUrl = Options::alloc()->themeUrl . '/assets/music/css/player.css';
        echo '<link rel="stylesheet" href="' . $cssUrl . '">';
if(Options::alloc()->music_sxj=='0'){	
			echo '<style>@media only screen and (max-width:766px){.ymusic{display:none}}</style>'. "\n";
}
    }
}
    public static function footer(){
        $options = Options::alloc();
    if ($options->music == '1'){
        $options = Options::alloc();
  $musicList = $options->music_musicList;
 if(empty($musicList)){
       $musicList = "761323";
      }
      
      if(strpos($musicList,'//')===false){
        $musicList = str_replace(PHP_EOL, '&br=128000&raw=ture"},{mp3:"//api.imjad.cn/cloudmusic/?type=song&id=', $musicList);  
  $musicList = '{mp3:"//api.imjad.cn/cloudmusic/?type=song&id='.$musicList.'&br=128000&raw=ture"}';
   $musicList = str_replace(array("\r\n", "\r", "\n", " "), "", $musicList);    
         }else{
              $musicList = str_replace(PHP_EOL, '"},{mp3:"', $musicList);  
  $musicList = '{mp3:"'.$musicList.'"}';
   $musicList = str_replace(array("\r\n", "\r", "\n", " "), "", $musicList);   
      
      }
if(strpos($musicList,',')===false){
    
		echo '
<bgm>			
<a class="ymusic" onclick="playbtu();" target="_blank"><i id="ydmc"></i></a>
</bgm>
             ';
}else{
      
		echo '
<bgm>			
<a class="ymusic" onclick="playbtu();" target="_blank"><i id="ydmc"></i></a><a class="ymusic" onclick="next();" id="ydnext" target="_blank"><i class="iconfont icon-you"></i></a>
</bgm>
             ';

}
      



        echo '<script data-no-instant>
var yaudio = new Audio();
yaudio.controls = true;
var musicArr=[
             '.$musicList.'
              ];
 
/*首次随机播放*/
var a=parseInt(Math.random()*musicArr.length);
var sj=musicArr[a];
yaudio.src=sj.mp3;
 ';
if(Options::alloc()->music_bof=='1'){	
			echo 'yaudio.play();</script>'. "\n";
		}else{	echo '</script>'. "\n";
}
        echo '<script  src="'.Options::alloc()->themeUrl . '/assets/music/js/player.js" data-no-instant></script><script  src="'.Options::alloc()->themeUrl . '/assets/music/js/prbug.js"></script>' . "\n";        
    }
}
    /**
     * 回复可见 Replyview
     * Date:09/10/2021
     *
     * @access public
     * @return void
     */ 
  public static function one($con,$obj,$text)
    {
      $text = empty($text)?$con:$text;
      if(!$obj->is('single') && strpos($text, '{bs-hide') !== false || strpos($text, '[bs-hide') !== false){
      $text = '文章包含隐藏内容，请进入文章内页查看~';
      }
      if(!$obj->is('single')){
      $text = preg_replace('/\{bs-(.*?)\}(.*?)\{\/bs-(.*?)\}/sm', '', $text);
      }
               return $text;
}   

       /**
     * 行为验证 Vaptcha
     * Date:09/10/2021
     *
     * @access public
     * @return void
     */ 
      /* 头部插入css */
    public static function vaptcha_header(){
        $options = Options::alloc();
    if ($options->VerifyChoose == '2'){
        $VAPTCHA_style = "
            <style>
                .vaptcha-container {
                    width: 100%;
                    height: 36px;
                    line-height: 36px;
                    text-align: center;
                }
                .vaptcha-init-main {
                    display: table;
                    width: 100%;
                    height: 100%;
                    background-color: #EEEEEE;
                }
               .vaptcha-init-loading {
                    display: table-cell;
                    vertical-align: middle;
                    text-align: center
                }
               .vaptcha-init-loading>a {
                    display: inline-block;
                    width: 18px;
                    height: 18px;
                    border: none;
                }
               .vaptcha-init-loading>a img {
                    vertical-align: middle
                }
               .vaptcha-init-loading .vaptcha-text {
                    font-family: sans-serif;
                    font-size: 12px;
                    color: #CCCCCC;
                    vertical-align: middle
                }
            </style>
        ";
        echo $VAPTCHA_style;
    }
}
    /*  尾部加入js */
    public static function vaptcha_footer(){
                $options = Options::alloc();
    if ($options->VerifyChoose == '2'){
        $options = Options::alloc();
      if ($options->VerifyChoose == '2'){
        $vaptcha_js = "
            <script src=\"https://v.vaptcha.com/v3.js\"></script>
            <script>
                document.getElementById(\"bearsimple_verify\").setAttribute(\"disabled\", true);
                vaptcha({
                    vid: '".$options->vid."', // 验证单元id
                    type: 'click', // 显示类型 点击式
                    container: '.vaptcha-container' // 按钮容器，可为Element 或者 selector
                }).then(function (vaptchaObj) {
                    vaptchaObj.listen('pass', function() {
                        document.getElementById(\"bearsimple_verify\").removeAttribute(\"disabled\");
                    })
                    vaptchaObj.render()
                })
            </script>
        ";
     
        
        echo $vaptcha_js;
    } 
    }
}
}
?>