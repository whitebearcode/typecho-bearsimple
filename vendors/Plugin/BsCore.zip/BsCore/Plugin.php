<?php
namespace TypechoPlugin\BsCore;
use Typecho\Plugin\PluginInterface;
use Typecho\Widget\Helper\Form;
use Typecho\Widget\Helper\Form\Element\Text;
use Widget\Options;
if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}
  
/**
 * BearSimple主题核心插件，针对Typecho1.2 Beta及以上版本，启用后无需其他设置，<a style="color:red">非Typecho1.2 Beta及以上版本请勿安装</a>
 *
 * @package BsCore
 * @author WhiteBear
 * @version 1.1.3
 * @link https://www.coder-bear.com/
 */
class Plugin implements PluginInterface
{
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     */
    public static function activate()
    {
    //代码高亮 
    \Typecho\Plugin::factory('Widget_Archive')->header = __CLASS__ .'::codehightlight_headlink';
    \Typecho\Plugin::factory('Widget_Archive')->footer = __CLASS__ .'::codehightlight_footlink';
    //缓存 
    \Typecho\Plugin::factory('index.php')->begin = __CLASS__ .'::cache_getCache';
    \Typecho\Plugin::factory('index.php')->end = __CLASS__ .'::cache_setCache';
    //验证->无感验证
    \Typecho\Plugin::factory('Widget_Feedback')->comment = __CLASS__ . '::beforeComment';
    \Typecho\Plugin::factory('Widget_Archive')->beforeRender = __CLASS__ . '::initCaptcha';
    //评论检验
    \Typecho\Plugin::factory('Widget_Feedback')->comment = __CLASS__ . '::filter';

    //编辑器美化->传统编辑器
    \Typecho\Plugin::factory('admin/write-post.php')->bottom = __CLASS__ . '::button';
    \Typecho\Plugin::factory('admin/write-page.php')->bottom = __CLASS__ . '::button';

    //回复可见处理
    \Typecho\Plugin::factory('Widget_Abstract_Contents')->excerptEx = __CLASS__ . '::one';
    \Typecho\Plugin::factory('Widget_Abstract_Contents')->contentEx = __CLASS__ . '::one';

    //置顶
    \Typecho\Plugin::factory('Widget_Archive')->indexHandle = __CLASS__ . '::sticky';
    return '启用成功，使用Bearsimple主题时本插件务必保持开启状态！';
    }

    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     */
    public static function deactivate()
    {
      return '禁用成功，使用Bearsimple主题时本插件务必保持开启状态！';
    }

    /**
     * 获取插件配置面板
     *
     * @param Form $form 配置面板
     */
    public static function config(Form $form)
    {
       
    }

    /**
     * 个人用户的配置面板
     *
     * @param Form $form
     */
    public static function personalConfig(Form $form)
    {
    }

    /**
     * 代码高亮 Codehightlight
     * Date:09/10/2021
     *
     * @access public
     * @return void
     */
     
    public static function codehightlight_headlink()
    {
       $options = Options::alloc();
    if ($options->Codehightlight == '1'){
        $dir = $options->themeUrl.'/';
   
    
        $style = Options::alloc()->code_style;
        if(empty($style)){
            $style = 'coy.css';
        }
        else{
       $style = Options::alloc()->code_style;
        }
        $cssUrl = $dir.'modules/codehightlight/static/styles/' . $style.'?v='.themeVersion();
        echo '<link rel="stylesheet" type="text/css" href="' . $cssUrl . '" />';
    }
    }
    
    public static function codehightlight_footlink()
    {
       $options = Options::alloc();
       if ($options->Codehightlight == '1'){
        $dir = $options->themeUrl.'/';
  
    
         $jsUrl = $dir.'modules/codehightlight/static/prism.js';
        $jsUrl_clipboard = $dir.'modules/codehightlight/static/clipboard.min.js';
        $showLineNumber = Options::alloc()->showLineNumber;
        if ($showLineNumber == '1') {
            echo <<<HTML
<script type="text/javascript">
	(function(){
		var pres = document.querySelectorAll('pre');
		var lineNumberClassName = 'line-numbers';
		pres.forEach(function (item, index) {
			item.className = item.className == '' ? lineNumberClassName : item.className + ' ' + lineNumberClassName;
		});
	})();
</script>
<script type="text/javascript">
$(document).on('pjax:complete', function() {
if (typeof Prism !== 'undefined') {
var pres = document.getElementsByTagName('pre');
                for (var i = 0; i < pres.length; i++){
                    if (pres[i].getElementsByTagName('code').length > 0)
                        pres[i].className  = 'line-numbers';}
Prism.highlightAll(true,null);}
});
</script>


HTML;
        }
        echo <<<HTML
<script type="text/javascript" src="{$jsUrl_clipboard}"></script>
<script type="text/javascript" src="{$jsUrl}"></script>

HTML;
    }
    }
  
    /**
     * 缓存 Cache
     * Date:09/10/2021
     *
     * @access public
     * @return void
     */ 
     
     public static function cache_getCache(){
         $options = Options::alloc();
         if ($options->Cache == '1'){
        $req = \Typecho\Request::getInstance();
        $url = $req->getRequestUri();


        if(!$req->isGet()){
            return;
        }
        if(strstr($url,'/action/') !== false || strstr($url,'/admin/') !== false){
            
            return;
        }

        $hash = md5($url);

        @$settings = Options::alloc();
        if(!$settings) return;


        $cache_timeout = intval($settings->cache_timeout);

        $cache_root = $settings->cache_dir;
        if(strstr($cache_root, '/') !== 0 ){
            $cache_root = __TYPECHO_ROOT_DIR__.'/usr/'.$cache_root;
        }

        if($cache_timeout <= 0){
            $cache_timeout = 60; //1min
        }

        $file = self::hash2dir($hash,$cache_root).$hash.".gz";
        if(file_exists($file)){
            $filetime = filemtime($file);
            if($filetime !== false && time() - $filetime < $cache_timeout){
                $fh = fopen($file, "rb");
                $content = fread($fh,filesize ($file));
                fclose($fh);
                $html = gzuncompress($content);
                echo $html;
                exit(0);
            }
        }else{
        
        }
    }
}

    public static function cache_setCache(){
        $options = Options::alloc();
         if ($options->Cache == '1'){
        $req = \Typecho\Request::getInstance();
        $url = $req->getRequestUri();
        
        if(!$req->isGet()){ #仅处理GET请求
            return;
        }
        if(strstr($url,'/action/') !== false || strstr($url,'/admin/') !== false){
            #排除action接口,这个一般是特殊接口,所以不需要缓存
            return;
        }

        @$settings = Options::alloc();
        if(!$settings) return;
        $cache_root = $settings->cache_dir;
        if(strstr($cache_root, '/') !== 0 ){
            $cache_root = __TYPECHO_ROOT_DIR__.'/usr/'.$cache_root;
        }

        $hash = md5($url);
        $file = self::hash2dir($hash,$cache_root).$hash.".gz";
        $dir = dirname($file);

        if(!file_exists($dir)){
            $ret = mkdir($dir,0777,true);
            if(!$ret){
                return;
            }
        }

        $html = ob_get_contents();
        $html_gz = gzcompress($html);
        $fp = fopen($file, 'w');
        fwrite($fp, $html_gz);
        fclose($fp);
    }
}

    private static function hash2dir($hash,$base_dir=""){
        $dir="";
        for($i = 0; $i < strlen($hash) ; $i+=2){
            $dir = $dir."/".substr($hash, $i, 2);
        }
        return rtrim($base_dir,'/').$dir.'/';
    }

    /**
     * 无感验证 SimpleCommentCaptcha
     * Date:09/10/2021
     *
     * @access public
     * @return void
     */ 

     protected static $session_key_prefix = 'SimpleCommentCaptcha_Plugin_';
    protected static $form_field_name = 'SimpleCommentCaptcha_Plugin_x';
    protected static $calculation_param_x;
    protected static $calculation_param_y;
    protected static $calculation_res;
    protected static $calculation_param_x_start;
    protected static $calculation_param_x_end;
     /**
     * 评论数据入库前校验
     *
     * @param array $comment
     * @param Widget_Archive $archive
     * @return void
     */
    public static function beforeComment($comment, $archive) {
        $options = Options::alloc();
    if ($options->VerifyChoose == '4'){
        $submit_x = (int) $archive->request->get(self::$form_field_name);
        $banned_ip_list = array_map(
            'trim',
            explode("\n", self::getFromOptions('banned_ip_list'))
        );

        if (in_array($comment['ip'], $banned_ip_list)) {
            // ip 在黑名单内
            throw new \Typecho\Widget\Exception(_t('您所在 ip 已被禁止评论操作！'));
        }

        if (
            $submit_x
            && self::getFromSession('x')
            && self::getFromSession('x') === $submit_x
        ) {
            // 校验成功
            self::removeFromSession('x');

            $spam_ip_action = self::getFromOptions('spam_ip_action');
            if ($spam_ip_action === '2') {
                // 若不处理存在垃圾评论的 ip ，直接返回
                return $comment;
            }

            if (in_array($comment['ip'], self::getCommentedTrashIpList())) {
                // ip 存在垃圾留言记录
                switch ($spam_ip_action) {
                    case '0':
                        $comment['status'] = 'waiting';
                        self::storeInSession(
                            'message',
                            _t('您的留言已进入待审核列表！')
                        );
                        break;
                    case '1':
                        $comment['status'] = 'spam';
                        break;
                }
            }
        } else {
            // 校验失败
            switch (self::getFromOptions('banned_action')) {
                case '0':
                    $comment['status'] = 'waiting';
                    self::storeInSession(
                        'message',
                        _t('您的留言已进入待审核列表！')
                    );
                    break;
                case '1':
                    $comment['status'] = 'spam';
                    break;
                case '2':
                    throw new \Typecho\Widget\Exception(_t('您的评论操作不合法！'));
            }
        }

        return $comment;
    }
}
    /**
     * 验证数据初始化、存储会话数据
     *
     * @param Widget_Archive $archive
     * @return void
     */
    public static function initCaptcha($archive)
    {
         $options = Options::alloc();
    if ($options->VerifyChoose == '4'){
        // 只在文章页和独立页面初始化验证数据（其他地方没有评论）
        if (!$archive->is('single') && !$archive->is('page')) {
            return ;
        }

        $start_num = 1000 * self::getFromOptions('protection_level');
        $end_num = $start_num * 10 - 1;
        self::$calculation_param_x_start = $start_num;
        self::$calculation_param_x_end = $end_num;
        self::$calculation_param_x = rand($start_num, $end_num);
        self::$calculation_param_y = rand(1, 1000) + 1;
        self::$calculation_res = self::calculateFunction(
            self::$calculation_param_x,
            self::$calculation_param_y
        );

        self::storeInSession('x', self::$calculation_param_x);
        self::storeInSession('y', self::$calculation_param_y);
        self::storeInSession('res', self::$calculation_res);
    }
}
    /**
     * 输出验证码所需表单内容和运算数据、过程
     * 需要在主题的评论区域（表单内部）调用
     *
     * @return void
     */
    public static function outputSimpleCommentCaptchaField($t)
    {
        $options = Options::alloc();
    if ($options->VerifyChoose == '4'){
        // 只在文章页和独立页面初始化验证数据（其他地方没有评论）
        if (!$t->is('single') && !$t->is('page')) {
            return ;
        }
        $message = self::getFromSession('message');
        $message = $message ? $message : '';

        if (self::getFromOptions('alert_message') === '0') {
            // 若关闭待审核 alert 提醒
            $message = '';
        }

        echo '<input name="'.self::$form_field_name.'" value="" hidden>';
        echo '<script> document.addEventListener("readystatechange",function(){'
            . '  if (document.readyState !== "interactive") {return;}'
            . '  setTimeout(function() {'
            . '    var SCCF_startX = ' . self::$calculation_param_x_start . ';'
            . '    var SCCF_endX = ' . self::$calculation_param_x_end .';'
            . '    var SCCF_res = ' . self::$calculation_res . ';'
            . '    var SCCF_paramY= ' . self::$calculation_param_y. ';'
            . '    var SCCF_tmpRes = 0;'
            . '    var SCCF_midM = 0;'
            . '    for (var i = SCCF_startX; i <= SCCF_endX; i++) {'
            . '      SCCF_midM = Math.abs('
            . '        Math.sin((i % Math.PI) * ((i + 2) % Math.PI) * 120)'
            . '      ) * 111;'
            . '      SCCF_midM *= 10000000;'
            . '      SCCF_tmpRes = Math.log(SCCF_midM) / Math.log(SCCF_paramY);'
            . '      if (Math.abs(SCCF_tmpRes - SCCF_res) < 0.0000000001) {'
            . '        var inputElement = document.getElementsByName("'
            .            self::$form_field_name . '")[0];'
            . 'inputElement.value = i;'
            . 'break;'
            . '}'
            . '}'
            . '},'.intval(self::getFromOptions('delay_time')) * 1000 .');'
            . 'var SCCF_message = "'.$message.'";'
            . 'if (SCCF_message) {alert(SCCF_message);}'
            . '});</script>';
        self::removeFromSession('message');
    }
}
    /**
     * 计算算子
     *
     * @param int $x 因子 x
     * @param int $y 因子 y
     * @return double 计算结果
     */
    public static function calculateFunction($x, $y)
    {
        $mid_num = abs(sin(fmod($x, pi()) * fmod($x + 2, pi()) * 120)) * 111;
        self::storeInSession('x', $x);
        return log($mid_num * 10000000, $y);
    }

    /**
     * 存储一项数据到会话
     *
     * @param string $name 会话数据项名称
     * @param mixed $value 会话数据项值
     * @return void
     */
    public static function storeInSession($name, $value)
    {
        self::ensureSessionStarted();
        $_SESSION[self::$session_key_prefix . $name] = $value;
    }

    /**
     * 从会话中获取一项数据
     *
     * @param string $name
     * @param mixed $default
     * @return void
     */
    public static function getFromSession($name, $default = null)
    {
        self::ensureSessionStarted();
        $key = self::$session_key_prefix . $name;
        if (isset($_SESSION[$key])) {
            return $_SESSION[$key];
        }
        return $default;
    }

    /**
     * 从会话中删除一项数据
     *
     * @param string $name 会话数据项名称
     * @return void
     */
    public static function removeFromSession($name)
    {
        self::ensureSessionStarted();
        unset($_SESSION[self::$session_key_prefix . $name]);
    }

    /**
     * 确保 session 开启
     *
     * @return void
     */
    public static function ensureSessionStarted()
    {
        if (!session_id()) {
            session_start();
        }
    }

    /**
     * 获取插件设置结果
     *
     * @param string $name 设置项名称
     * @return string
     */
    public static function getFromOptions($name)
    {
        return Options::alloc()->{$name};
    }

    /**
     * 获取存在垃圾评论的 ip 列表
     *
     * @return array
     */
    public static function getCommentedTrashIpList()
    {
        $db = \Typecho\Db::get();
        $ip_list = $db->fetchAll(
            $db->select('ip')->from('table.comments')
                ->where('status = ?', 'spam')
        );
        return array_column($ip_list, 'ip');
    }
    
     /**
     * 评论检验 CheckSec
     * Date:09/10/2021
     *
     * @access public
     * @return void
     */ 
     public static function xsscheck($text)
{
    $xsscheck = false;
    $list = array(
        '/onabort/is',
        '/onblur/is',
        '/onchange/is',
        '/onclick/is',
        '/ondblclick/is',
        '/onerror/is',
        '/onfocus/is',
        '/onkeydown/is',
        '/onkeypress/is',
        '/onkeyup/is',
        '/onload/is',
        '/onmousedown/is',
        '/onmousemove/is',
        '/onmouseout/is',
        '/onmouseover/is',
        '/onmouseup/is',
        '/onreset/is',
        '/onresize/is',
        '/onselect/is',
        '/onsubmit/is',
        '/onunload/is',
        '/eval/is',
        '/ascript:/is',
        '/style=/is',
        '/width=/is',
        '/width:/is',
        '/height=/is',
        '/height:/is',
        '/src=/is',
    );
    if (strip_tags($text)) {
        for ($i = 0; $i < count($list); $i++) {
            if (preg_match($list[$i], $text) > 0) {
                $xsscheck = true;
                break;
            }
        }
    } else {
        $xsscheck = true;
    };
    return $xsscheck;
}

/**
    * PHP获取字符串中英文混合长度 
    */
    public static function strLength($str){        
        preg_match_all('/./us', $str, $match);
        return count($match[0]);  // 输出9
    }
        

    /**
     * 检查$str中是否含有$words_str中的词汇
     * 
     */
	public static function check_in($words_str, $str)
	{
		$words = explode("\n", $words_str);
		if (empty($words)) {
			return false;
		}
		foreach ($words as $word) {
            if (false !== strpos($str, trim($word))) {
                return true;
            }
		}
		return false;
	}

    /**
     * 检查$ip中是否在$words_ip的IP段中
     * 
     */
	public static function check_ip($words_ip, $ip)
	{
		$words = explode("\n", $words_ip);
		if (empty($words)) {
			return false;
		}
		foreach ($words as $word) {
			$word = trim($word);
			if (false !== strpos($word, '*')) {
				$word = "/^".str_replace('*', '\d{1,3}', $word)."$/";
				if (preg_match($word, $ip)) {
					return true;
				}
			} else {
				if (false !== strpos($ip, $word)) {
					return true;
				}
			}
		}
		return false;
	}
	
 public static function filter($comment,$post){
 $options = Options::alloc();
         if (strlen(trim(preg_replace('/\xc2\xa0/',' ',$comment['text']))) == 0) {
			\Typecho\Cookie::set('__typecho_remember_text', $comment['text']);
			throw new \Typecho\Widget\Exception("抱歉，系统检测到您的评论内容只有空格，请返回修改后再试。");
            }
            
        if(Plugin::xsscheck($comment['text'])) {
			\Typecho\Cookie::set('__typecho_remember_text', $comment['text']);
			throw new \Typecho\Widget\Exception("抱歉，系统检测到您的评论包含危险内容，请返回修改后再试。");
        }
        
        if (!empty($options->BearSpam_IP)) {
			if (Plugin::check_ip($options->BearSpam_IP, $comment['ip'])) {
			throw new \Typecho\Widget\Exception("抱歉，系统检测到您的IP处于屏蔽范围内，已拦截本条评论。");
			  \Typecho\Cookie::set('__typecho_remember_text', $comment['text']);
			}

            
        }
		if (!empty($options->BearSpam_EMAIL)) {
			if (Plugin::check_in($options->BearSpam_EMAIL, $comment['mail'])) {
				throw new \Typecho\Widget\Exception("抱歉，系统检测到您的邮箱处于屏蔽范围内，已拦截本条评论。");
				  \Typecho\Cookie::set('__typecho_remember_text', $comment['text']);
			}
		}
		
			if (!empty($options->BearSpam_NAME)) {
			if (Plugin::check_in($options->BearSpam_NAME, $comment['author'])) {
				throw new \Typecho\Widget\Exception("抱歉，系统检测到您的昵称存在敏感禁止词汇，已拦截本条评论。");
				  \Typecho\Cookie::set('__typecho_remember_text', $comment['text']);
			}
		}
		
		if (!empty($options->BearSpam_URL)) {
			if (Plugin::check_in($options->BearSpam_URL, $comment['url'])) {
			    			throw new \Typecho\Widget\Exception("抱歉，系统检测到您的网址处于屏蔽范围内，已拦截本条评论。");
			\Typecho\Cookie::set('__typecho_remember_text', $comment['text']);
			}
			}
			
			if (!empty($options->BearSpam_ArticleTitle)&& $options->BearSpam_ArticleTitle == "1") {
			$db = \Typecho\Db::get();
            // 获取评论所在文章
            $pot = $db->fetchRow($db->select('title')->from('table.contents')->where('cid = ?', $comment['cid']));        
            if(strstr($comment['text'], $pot['title'])){
                		throw new \Typecho\Widget\Exception("抱歉，系统检测到您的评论内容疑似存在灌水内容，已自动拦截。");
\Typecho\Cookie::set('__typecho_remember_text', $comment['text']);
			}
			}
			
			if (!empty($options->BearSpam_NAMEMIN)) {    
            if(Plugin::strLength($comment['author']) < $options->BearSpam_NAMEMIN){

			throw new \Typecho\Widget\Exception("抱歉，系统检测到您的评论昵称过短，已自动拦截。");
			\Typecho\Cookie::set('__typecho_remember_text', $comment['text']);
			}
			}
			
			if (!empty($options->BearSpam_NAMEMAX)) {    
            if (Plugin::strLength($comment['author']) > $options->BearSpam_NAMEMAX) {
                throw new \Typecho\Widget\Exception("抱歉，系统检测到您的评论昵称过长，已自动拦截。");
			\Typecho\Cookie::set('__typecho_remember_text', $comment['text']);
			}}
			
			if (!empty($options->BearSpam_NAMEURL)&& $options->BearSpam_NAMEURL == "1") {    
            if (preg_match(" /^((https?|ftp|news):\/\/)?([a-z]([a-z0-9\-]*[\.。])+([a-z]{2}|aero|arpa|biz|com|coop|edu|gov|info|int|jobs|mil|museum|name|nato|net|org|pro|travel)|(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5]))(\/[a-z0-9_\-\.~]+)*(\/([a-z0-9_\-\.]*)(\?[a-z0-9+_\-\.%=&]*)?)?(#[a-z][a-z0-9_]*)?$/ ", $comment['author']) > 0) {
			                throw new \Typecho\Widget\Exception("抱歉，系统检测到您的评论昵称异常，已自动拦截。");
			\Typecho\Cookie::set('__typecho_remember_text', $comment['text']);
			}}
			
			if (!empty($options->BearSpam_Chinese)&& $options->BearSpam_Chinese == "1") {    
            if (preg_match("/[\x{4e00}-\x{9fa5}]/u", $comment['text']) == 0) {
			throw new \Typecho\Widget\Exception("抱歉，系统检测到您的评论内容不包含中文，已自动拦截。");
			\Typecho\Cookie::set('__typecho_remember_text', $comment['text']);
			}}
			
			if (!empty($options->BearSpam_MIN)) {    
            if(Plugin::strLength($comment['text']) < $options->BearSpam_MIN){         
				throw new \Typecho\Widget\Exception("抱歉，系统检测到您的评论内容字数过少，已自动拦截。");
			\Typecho\Cookie::set('__typecho_remember_text', $comment['text']);
			}}
			
			if (!empty($options->BearSpam_Words)) {    
            if (Plugin::check_in($options->BearSpam_Words, $comment['text'])) { 
	throw new \Typecho\Widget\Exception("抱歉，系统检测到您的评论内容包含敏感禁止词汇，已自动拦截。");
			\Typecho\Cookie::set('__typecho_remember_text', $comment['text']);
			}
					    
			}
            \Typecho\Cookie::delete('__typecho_remember_text');
        return $comment;
 }
 
    
    /**
     * 编辑器美化 传统/新版编辑器
     * Date:26/11/2021
     *
     * @access public
     * @return void
     */ 
     public static function button(){
         $options = Options::alloc();
         if (strpos( $_SERVER['REQUEST_URI'],'write-post.php') !== false)
{
    $url = 'post';
        \Widget\Contents\Post\Edit::alloc()->to($post);
}
if (strpos( $_SERVER['REQUEST_URI'],'write-page.php') !== false)
{
    $url = 'page';
\Widget\Contents\Page\Edit::alloc()->to($page);
}

if (isset($post) || isset($page)) {
    $cid = isset($post) ? $post->cid : $page->cid;

    if ($cid) {
        \Widget\Contents\Attachment\Related::alloc(['parentId' => $cid])->to($attachment);
    } else {
        \Widget\Contents\Attachment\Unattached::alloc()->to($attachment);
    }
}
\Widget\Security::alloc()->to($security);
         if($options->editor == '2'){
           $cssUrl = '//deliver.application.pub/npm/easymde@2.15.0/dist/easymde.min.css';
        $jsUrl = '//deliver.application.pub/npm/easymde@2.15.0/dist/easymde.min.js';
		?>
		<script>
		$(document).ready(function(){
		    $("#wmd-button-bar").hide();
		});
		    </script>
<link rel="stylesheet" href="//cdn.staticfile.org/font-awesome/4.7.0/css/font-awesome.min.css" />
        <link rel="stylesheet" href="<?php echo $cssUrl; ?>" />
<link rel="stylesheet" href="//cdn.staticfile.org/limonte-sweetalert2/11.3.10/sweetalert2.min.css" />
        <script type="text/javascript" src="<?php echo $jsUrl; ?>"></script>
<link href="//deliver.application.pub/npm/@sweetalert2/theme-bootstrap-4/bootstrap-4.css" rel="stylesheet">

        <script src="//cdn.staticfile.org/limonte-sweetalert2/11.3.10/sweetalert2.min.js"></script>
<link rel="stylesheet" href="//cdn.staticfile.org/bootstrap-colorpicker/3.4.0/css/bootstrap-colorpicker.min.css" />
<script type="text/javascript" src="//cdn.staticfile.org/bootstrap-colorpicker/3.4.0/js/bootstrap-colorpicker.min.js"></script>
	<link href="//cdn.staticfile.org/toastr.js/2.1.4/toastr.min.css" rel="stylesheet">
	<script src="//cdn.staticfile.org/toastr.js/2.1.4/toastr.min.js"></script>
	<style>
    .editor-statusbar .lines:before{content:'行数: '}
    .editor-statusbar .words:before{content:'字数: '}
</style>
        <script>
            $(document).ready(function() {
                new EasyMDE({
        autoDownloadFontAwesome: false,
        showIcons: ['strikethrough', 'code', 'table', 'redo', 'heading', 'undo', 'heading-bigger', 'heading-smaller', 'heading-1', 'heading-2', 'heading-3', 'clean-block', 'horizontal-rule','side-by-side'],
        <?php if($options->EditorsAutosave[0] == '1'):?>
        autosave: {
            enabled: true,
            delay: 1000,
            uniqueId: 'text',
            timeFormat:{locale:'zh-CN'},
            text:'自动保存时间：'
        },
        <?php endif; ?>
        toolbar: [ { name: "bold", action:EasyMDE.toggleBold, className: "fa fa-bold",title: "加粗"}, { name: "italic", action:EasyMDE.toggleItalic, className: "fa fa-italic",title: "字体倾斜"}, { name: "strikethrough", action:EasyMDE.toggleStrikethrough, className: "fa fa-strikethrough",title: "删除线"},{ name: "heading-smaller", action:EasyMDE.toggleHeadingSmaller, className: "fa fa-header",title: "字体缩小"}, { name: "heading-bigger", action:EasyMDE.toggleHeadingBigger, className: "fa fa-header",title: "字体放大"},{ name: "heading-1", action:EasyMDE.toggleHeading1, className: "fa fa-header header-1",title: "H1字号"},{ name: "heading-2", action:EasyMDE.toggleHeading2, className: "fa fa-header header-2",title: "H2字号"},{ name: "heading-3", action:EasyMDE.toggleHeading3, className: "fa fa-header header-3",title: "H3字号"}, { name: "code", action:EasyMDE.toggleCodeBlock, className: "fa fa-code",title: "代码"}, { name: "quote", action:EasyMDE.toggleBlockquote, className: "fa fa-quote-left",title: "引用"}, { name: "unordered-list", action:EasyMDE.toggleUnorderedList, className: "fa fa-list-ul",title: "无序列表"}, { name: "ordered-list", action:EasyMDE.toggleOrderedList, className: "fa fa-list-ol",title: "有序列表"}, { name: "clean-block", action:EasyMDE.cleanBlock, className: "fa fa-eraser",title: "擦除代码块"}, { name: "link", action:EasyMDE.drawLink, className: "fa fa-link",title: "插入链接"}, { name: "image", action:EasyMDE.drawImage, className: "fa fa-picture-o",title: "插入图片"}, '|', { name: "table", action:EasyMDE.drawTable, className: "fa fa-table",title: "插入表格"}, { name: "color", className: "fa fa-font", action:colorpc,title: "字体颜色选择器"},{ name: "button", className: "fa fa-circle-o-notch", action:button,title: "按钮"},{ name: "message", className: "fa fa-sticky-note-o", action:message,title: "提示框"},{ name: "iframe", className: "fa fa-window-maximize", action:iframe,title: "插入iframe"},{ name: "audio", className: "fa fa-file-audio-o", action:audio,title: "插入音频"},{ name: "hide", className: "fa fa-commenting", action:hide,title: "回复或登录后可见"},{ name: "login", className: "fa fa-user-circle", action:login,title: "登录后可见"},{ name: "inserts", className: "fa fa-paperclip", action:attachInsertEvent,title: "插入所有附件"},{ name: "insertper", className: "fa fa-paperclip", action:insertper,title: "插入单个附件"},{ name: "copyupload", className: "fa fa-paperclip", action:copyupload,title: "复制粘贴上传"},{ name: "star", className: "fa fa-star-half-o", action:star,title: "评星"},{ name: "todolist1", className: "fa fa-check-square", action:todolist1,title: "已完成列表"},{ name: "todolist2", className: "fa fa-square", action:todolist2,title: "未完成列表"},{ name: "accord1", className: "fa fa-plus-square", action:accord1,title: "线性手风琴"},{ name: "accord2", className: "fa fa-plus-square-o", action:accord2,title: "普通手风琴"},{ name: "quotepost", className: "fa fa-newspaper-o", action:quotepost,title: "引用文章"},{ name: "postmark", className: "fa fa-bookmark-o", action:postmark,title: "标注文字"},{ name: "postruby", className: "fa fa-file-word-o", action:postruby,title: "文字带拼音"},{ name: "gallery", className: "fa fa-file-image-o", action:gallery,title: "相册"},{ name: "githubcard", className: "fa fa-github", action:githubcard,title: "Github仓库"},{ name: "autosaves", className: "fa fa-grav", action:autosave,title: "自动保存"},{ name: "progress", className: "fa fa-product-hunt", action:progress,title: "进度条"},{ name: "preview", action:EasyMDE.togglePreview, className: "fa fa-eye no-disable",title: "预览"}, { name: "side-by-side", action:EasyMDE.toggleSideBySide, className: "fa fa-columns no-disable no-mobile",title: "所见即所得"}, { name: "fullscreen", action:EasyMDE.toggleFullScreen, className: "fa fa-arrows-alt no-disable no-mobile",title: "全屏"}, '|', ],
        lineNumbers:false,
        promptURLs:true,
        promptTexts:{
            image:"请填写图片直链",
            link:"请填写网址链接",
        },
        element: document.getElementById('text'),
    });
            });
            
            function copyupload(editor){
                    $(document).on('paste', function(event) {
                        event = event.originalEvent;
                        var cbd = event.clipboardData;
                        var ua = window.navigator.userAgent;
                        var uploadURL = '<?php $security->index('/action/upload?cid=CID'); ?>';
                        if (!(event.clipboardData && event.clipboardData.items)) {
                            return;
                        }

                        if (cbd.items && cbd.items.length === 2 && cbd.items[0].kind === "string" && cbd.items[1].kind === "file" &&
                            cbd.types && cbd.types.length === 2 && cbd.types[0] === "text/plain" && cbd.types[1] === "Files" &&
                            ua.match(/Macintosh/i) && Number(ua.match(/Chrome\/(\d{2})/i)[1]) < 49){
                            return;
                        }

                        var itemLength = cbd.items.length;

                        if (itemLength == 0) {
                            return;
                        }

                        if (itemLength == 1 && cbd.items[0].kind == 'string') {
                            return;
                        }

                        if ((itemLength == 1 && cbd.items[0].kind == 'file')
                                || itemLength > 1
                            ) {
                            for (var i = 0; i < cbd.items.length; i++) {
                                var item = cbd.items[i];

                                if(item.kind == "file") {
                                    var blob = item.getAsFile();
                                    if (blob.size === 0) {
                                        return;
                                    }
                                    var ext = blob.name.substring(blob.name.lastIndexOf(".")+1);
                                    var formData = new FormData();
                                    formData.append('blob', blob, Math.floor(new Date().getTime() / 1000) + '.' + ext);
                                    var uploadingText = '![文件上传中(' + i + ')...]';
                                    var uploadFailText = '![文件上传失败(' + i + ')]'
                                    $.ajax({
                                        method: 'post',
                                        url: uploadURL.replace('CID', $('input[name="cid"]').val()),
                                        data: formData,
                                        contentType: false,
                                        processData: false,
                                        success: function(data) {
                                            if (data[0]) {
                                                var filehz = data[0].substring(data[0].lastIndexOf(".")+1);
                                                switch(filehz){
                                                 case 'gif':
                                                 editor.codemirror.doc.replaceSelection('![](' + data[0] + ')\n');
                                                 break;
                                                 case 'jpg':
                                                 editor.codemirror.doc.replaceSelection('![](' + data[0] + ')\n');
                                                 break;
                                                 case 'jpeg':
                                                 editor.codemirror.doc.replaceSelection('![](' + data[0] + ')\n');
                                                 break;
                                                 case 'gif':
                                                 editor.codemirror.doc.replaceSelection('![](' + data[0] + ')\n');
                                                 break;
                                                 case 'png':
                                                 editor.codemirror.doc.replaceSelection('![](' + data[0] + ')\n');
                                                 break;
                                                 case 'tiff':
                                                 editor.codemirror.doc.replaceSelection('![](' + data[0] + ')\n');
                                                 break;
                                                 case 'bmp':
                                                 editor.codemirror.doc.replaceSelection('![](' + data[0] + ')\n');
                                                 break;
                                                 case 'svg':
                                                 editor.codemirror.doc.replaceSelection('![](' + data[0] + ')\n');
                                                 break;
                                                 case 'ico':
                                                 editor.codemirror.doc.replaceSelection('![](' + data[0] + ')\n');
                                                 break;
                                                 default:
                                                 editor.codemirror.doc.replaceSelection('['+data[1]['cid']+']['+data[1]['cid']+']\n['+data[1]['cid']+']: ' + data[0]+'\n');
                                                }
                                                
                                            } else {
                                               editor.codemirror.doc.replaceSelection(uploadFailText);
                                            }
                                        },
                                        error: function() {
                                            editor.codemirror.doc.replaceSelection(uploadFailText);
                                        }
                                    });
                                }
                            }

                        }

			});
       }
       
              setTimeout(function() {
                var button = $(".copyupload");
                button.click();
            }, 2000);
       
       
       
            
            function star(editor){
               Swal.fire({
  title: '第一步 选择评星样式',
  input: 'select',
  inputOptions: {
      'star': '星星',
      'heart': '红心',
  },
  inputPlaceholder: '选择一款样式',
  showCancelButton: true,
cancelButtonText: "取消", 
  confirmButtonText: '下一步',
  inputValidator: (valueone) => {
    return new Promise((resolve) => {
      if (valueone !== '') {

                Swal.fire({
  title: '第二步 输入评星数目',
  input: 'number',
inputLabel: '输入评星数目，最高五颗星',
inputAttributes:{
  min:1,
  max:5,
  
},
  inputPlaceholder: '输入评星数目',
  showCancelButton: true,
cancelButtonText: "取消", 
  confirmButtonText: '插入',
  inputValidator: (valuetwo) => {
    return new Promise((resolve) => {
      if (valuetwo !== '') {
var text = '[bseva type="'+valueone+'"]'+valuetwo+'[/bseva]';
      editor.codemirror.doc.replaceSelection(text);
        
        resolve() 
      } 
      else{
         resolve('您必须输入评星数目~~') 
      }
    })
  }
})

        
    
        resolve() 
      } 
      else{
         resolve('您必须选择一款评星样式~~') 
      }
    })
  }
}) 
            }
            function autosave(editor){
          <?php if($options->EditorsAutosave[0] == '11'||$options->EditorsAutosave[1] == '11'):?>
            //$("textarea:eq(1)").bind("input propertychange", autosaves); //废弃方法
        setInterval(function(){
         var submitted = false, form = $('form[name=write_post],form[name=write_page]').submit(function () {
        submitted = true;
    }), formAction = form.attr('action'),
        idInput = $('input[name=cid]'),
        cid = idInput.val(),
        draft = $('input[name=draft]'),
        draftId = draft.length > 0 ? draft.val() : 0,
        btnSave = $('#btn-save').removeAttr('name').removeAttr('value'),
        btnSubmit = $('#btn-submit').removeAttr('name').removeAttr('value'),
        btnPreview = $('#btn-preview'),
        doAction = $('<input type="hidden" name="do" value="publish" />').appendTo(form),
        locked = false,
        changed = false,
        autoSave = $('<span id="auto-save-message" class="left"></span>').prependTo('.submit'),
        lastSaveTime = null;
        var data = new FormData(form.get(0));
        data.set("text",editor.value());
        var localcid = "<?php echo $cid;?>";
if(localcid == '' && localStorage.getItem('autosavecid') && localStorage.getItem('autosavecid') !== ''){
data.set("cid",localStorage.getItem('autosavecid'));
}
else{
    data.set("cid",localcid);
}
     
        function callback(o) {
toastr.success('已自动保存为草稿<br>保存时间:'+o.time);   
localStorage.setItem('autosavecid',o.cid);

        }
                
            data.append('do', 'save');
            
  $.ajax({
                url: formAction,
                processData: false,
                contentType: false,
                type: 'POST',
                data: data,
                success: callback
            });    
   },15000); 
   <?php endif; ?>
}
            
                setTimeout(function() {
                var buttons = $(".autosaves");
                buttons.click();
            }, 2000);
            
           function confirmEnding(str, target) {
  var start = str.length-target.length;
  var arr = str.substr(start,target.length);
  if(arr == ".jpg" || arr == ".jpeg" || arr == ".png" || arr == ".gif"){
    return '1';
  }
 return '2';
}

            setTimeout(function() {
                var button = $(".insertper");
                button.click();
            }, 2000);
        function insertper (editor) {
  $('#file-list').on('mousedown', '.insert', function(){
      var s=$(this).parents("li").data('url');
var name = '.'+ s.substring(s.lastIndexOf(".")+1);
   var end = confirmEnding(s, name);
   if(end == '1'){
        var filenames="!["+$(this).parents("li").data('cid')+"]["+$(this).parents("li").data('cid')+"]\n";
   }
   else{
       var filenames="["+$(this).parents("li").data('cid')+"]["+$(this).parents("li").data('cid')+"]\n";
   }
	    var fileurls="\n  ["+$(this).parents("li").data('cid')+"]: "+$(this).parents("li").data('url');
                 editor.codemirror.doc.replaceSelection(filenames + fileurls); 
});
    }

             function attachInsertEvent (editor) {
                 function getData() {
                    $.ajax({
                        type: "GET",
                        url: "<?php getAttachFile(); ?>",
                        data: {
                            "cid": "<?php echo $cid; ?>",
                             "url": "<?php echo $url; ?>",
                        },
                        dateType: "json",
                        success: function(json) {
                            json = JSON.parse(json);
                            content(json.list);
                        },
                        complete: function() {
                        },
                        error: function() {
                            alert("数据获取错误");
                        }
                    });
                }
                getData();
                function content(list) {
                    var filename = " ";
                    var fileurl = " ";
                    for(var i in list) {
                        if(list[i]['type'] == 'img'){
                        filename += '![' + list[i]['title'] + '][' + list[i]['cid'] + ']\n'
fileurl += '\n  [' + list[i]['cid'] + ']:' + list[i]['url']
}
                        if(list[i]['type'] == 'other'){
                        filename += '[' + list[i]['title'] + '][' + list[i]['cid'] + ']\n'
fileurl += '\n  [' + list[i]['cid'] + ']:' + list[i]['url']
}
}
editor.codemirror.doc.replaceSelection(filename + fileurl);
}
    }
    function iframe(editor){
    editor.codemirror.doc.replaceSelection('{bs-iframe}iframe地址，可为video等{/bs-iframe}'); 
            }
            function githubcard(editor){
    editor.codemirror.doc.replaceSelection('[bsgit user="Github仓库拥有者，如whitebearcode"]Github项目名，如typecho-bearsimple[/bsgit]'); 
            }
            function hide(editor){
    editor.codemirror.doc.replaceSelection('[bshide]隐藏内容[/bshide]'); 
            }
            function gallery(editor){
    editor.codemirror.doc.replaceSelection('[bsgallery title="相册名"]\n[bsimg title="图片标题1" subtitle="图片子标题1"]图片地址1[/bsimg]\n[bsimg title="图片标题2" subtitle="图片子标题2"]图片地址2[/bsimg]\n[bsimg title="图片标题3" subtitle="图片子标题3"]图片地址3[/bsimg]\n[/bsgallery]'); 
            }
            function login(editor){
    editor.codemirror.doc.replaceSelection('[bslogin]隐藏内容[/bslogin]'); 
            }
            function audio(editor){
    editor.codemirror.doc.replaceSelection('[bsaudio}]音频地址[/bsaudio]'); 
            }
            function accord1(editor){
    editor.codemirror.doc.replaceSelection('{bs-accord style=line title=线性手风琴标题}线性手风琴内容{/bs-accord}'); 
            }
            function accord2(editor){
    editor.codemirror.doc.replaceSelection('{bs-accord style=common title=普通手风琴标题}普通手风琴内容{/bs-accord}'); 
            }
            function quotepost(editor){
    editor.codemirror.doc.replaceSelection('[bspost cid="文章CID"]'); 
            }
            function postmark(editor){
    editor.codemirror.doc.replaceSelection('[bsmark]要标注的内容[/bsmark]'); 
            }
            function postruby(editor){
    editor.codemirror.doc.replaceSelection('[bsruby]要带拼音的汉字[/bsruby]'); 
            }
             function todolist1(editor){
    editor.codemirror.doc.replaceSelection('[todo-t]已完成的内容[/todo-t]'); 
            }
             function todolist2(editor){
    editor.codemirror.doc.replaceSelection('[todo-f]未完成的内容[/todo-f]'); 
            }



function button(editor){
         Swal.fire({
  title: '第一步 选择按钮样式',
  input: 'select',
  inputOptions: {
      'common': '普通按钮',
      'basic': '光圈按钮',
      'animated': '动画按钮',
  },
  inputPlaceholder: '选择一款按钮',
  showCancelButton: true,
cancelButtonText: "取消", 
  confirmButtonText: '下一步',
  inputValidator: (valueone) => {
    return new Promise((resolve) => {
      if (valueone !== '') {

                Swal.fire({
  title: '第二步 选择按钮颜色',
  input: 'select',
  inputOptions: {
      'standard': '淡色',
      'primary': '蓝色',
      'secondary': '黑色',
      'red': '红色',
      'orange': '橙色',
      'yellow': '黄色',
      'olive': '淡绿色',
      'green': '深绿色',
      'teal': '青色',
      'violet': '紫罗兰色',
      'purple': '基佬紫色',
      'pink': '粉色',
      'brown': '土黄色',
      'grey': '灰色',
  },
  inputPlaceholder: '选择一款颜色',
  showCancelButton: true,
cancelButtonText: "取消", 
  confirmButtonText: '下一步',
  inputValidator: (valuetwo) => {
    return new Promise((resolve) => {
      if (valuetwo !== '') {
        
        

  Swal.fire({
      title: '第三步 填写按钮点击链接',
  input: 'url',
  inputLabel: '按钮点击跳转链接',
  inputPlaceholder: '填写按钮点击跳转链接，需带http(s)://',
    showCancelButton: true,
cancelButtonText: "取消", 
  confirmButtonText: '下一步',
  inputValidator: (valuethree) => {
    return new Promise((resolve) => {
      if (valuethree !== '') {
        
        
        Swal.fire({
  title: '第四步 填写按钮名称',
  input: 'text',
  inputLabel: '按钮名称(若为动画按钮，两个名称请使用|隔开)',
  inputPlaceholder: '请填写按钮名称',
  showCancelButton: true,
  cancelButtonText: "取消", 
  confirmButtonText: '下一步',
  inputValidator: (valuefour) => {
    if (!valuefour) {
      return '您必须填写按钮名称'
    }
    else{
        
        
        
        Swal.fire({
  title: '第五步 填写按钮图标名',
  input: 'text',
  inputLabel: '按钮图标名(若不需要图标可留空)',
  'html':'<a href="https://icon.bearlab.eu/" target="_blank">图标获取请戳这里</a>',
  inputPlaceholder: '请填写按钮图标名',
  showCancelButton: true,
  cancelButtonText: "取消", 
  confirmButtonText: '插入',
  inputValidator: (valuefive) => {
      if(!valuefive){
          var icon = '';
      }
      else{
          var icon = ' icon="'+valuefive+'"';
      }
      var text = '[bsbtn type="'+valueone+'" color="'+valuetwo+'" url="'+valuethree+'"'+icon+']'+valuefour+'[/bsbtn]';
      editor.codemirror.doc.replaceSelection(text);
    resolve()
  }
})
        
        
        
        resolve()
    }
  }
})
        
        
        
        resolve() 
      } 
      else{
         resolve('您必须填写跳转链接~~') 
      }
    })
  }
})

        
        
        
        
        
        resolve() 
      } 
      else{
         resolve('您必须选择一款颜色~~') 
      }
    })
  }
})

        
        
        
        
        
        
        
        
        resolve() 
      } 
      else{
         resolve('您必须选择一款按钮~~') 
      }
    })
  }
})

      }
      
      function progress(editor){
         Swal.fire({
  title: '选择进度条颜色',
  input: 'select',
  inputOptions: {
      'normal':'蓝色',
      'success': '绿色',
      'info': '青色',
      'warning': '黄色',
      'danger': '红色',
      'light': '白色',
      'dark': '黑色',
  },
  inputPlaceholder: '选择一款颜色',
  showCancelButton: true,
cancelButtonText: "取消", 
  confirmButtonText: '下一步',
  inputValidator: (valueone) => {
    return new Promise((resolve) => {
      if (valueone !== '') {
      
      Swal.fire({
      title: '第二步 填写进度条标题',
  input: 'text',
  inputLabel: '进度条标题[将显示在进度条上方]',
  inputPlaceholder: '填写进度条标题',
    showCancelButton: true,
cancelButtonText: "取消", 
  confirmButtonText: '下一步',
  inputValidator: (valuetwo) => {
    return new Promise((resolve) => {
      if (valuetwo !== '') {
             Swal.fire({
      title: '第三步 填写进度条数值',
  input: 'text',
  inputLabel: '进度条数值[如40%就填写40]',
  inputPlaceholder: '填写进度条数值',
    showCancelButton: true,
cancelButtonText: "取消", 
  confirmButtonText: '插入',
  inputValidator: (valuethree) => {
    return new Promise((resolve) => {
      if (valuethree !== '') {
                var text = '[bsprog color="'+valueone+'" number="'+valuethree+'"]'+valuetwo+'[/bsprog]';
      editor.codemirror.doc.replaceSelection(text);
    resolve()
      }
      else{
       resolve('您必须填写进度条数值~')    
      }
    })
  }
})
    resolve()
      }
      else{
       resolve('您必须填写进度条标题~')    
      }
    })
  }
})
      
      
      
      
      } 
      else{
         resolve('您必须选择一款颜色~') 
      }
    })
  }
})

      }
      
      function message(editor){
         Swal.fire({
  title: '第一步 选择提示框样式',
  input: 'select',
  inputOptions: {
      'common': '普通提示框',
      'basic': '阴影提示框',
      'commonclose': '普通可关闭提示框',
      'basicclose':'阴影可关闭提示框',
  },
  inputPlaceholder: '选择一款提示框',
  showCancelButton: true,
cancelButtonText: "取消", 
  confirmButtonText: '下一步',
  inputValidator: (valueone) => {
    return new Promise((resolve) => {
      if (valueone !== '') {

                Swal.fire({
  title: '第二步 选择提示框颜色',
  input: 'select',
  inputOptions: {
      'standard': '淡色',
      'info':'淡青色',
      'primary': '蓝色',
      'secondary': '黑色',
      'red': '红色',
      'orange': '橙色',
      'yellow': '黄色',
      'olive': '淡绿色',
      'green': '深绿色',
      'teal': '青色',
      'violet': '紫罗兰色',
      'purple': '基佬紫色',
      'pink': '粉色',
      'brown': '土黄色',
      'grey': '灰色',
  },
  inputPlaceholder: '选择一款颜色',
  showCancelButton: true,
cancelButtonText: "取消", 
  confirmButtonText: '下一步',
  inputValidator: (valuetwo) => {
    return new Promise((resolve) => {
      if (valuetwo !== '') {
        
        

  Swal.fire({
      title: '第三步 填写提示框标题',
  input: 'text',
  inputLabel: '提示框标题',
  inputPlaceholder: '填写提示框标题',
    showCancelButton: true,
cancelButtonText: "取消", 
  confirmButtonText: '下一步',
  inputValidator: (valuethree) => {
    return new Promise((resolve) => {
      if (valuethree !== '') {
        
        
        Swal.fire({
  title: '第四步 填写提示框内容',
  input: 'textarea',
  inputLabel: '提示框内容',
  inputPlaceholder: '请填写提示框内容',
  showCancelButton: true,
  cancelButtonText: "取消", 
  confirmButtonText: '下一步',
  inputValidator: (valuefour) => {
    if (!valuefour) {
      return '您必须填写提示框内容'
    }
    else{
        
        
        
        Swal.fire({
  title: '第五步 填写提示框图标名',
  input: 'text',
  inputLabel: '提示框图标名(若不需要图标可留空)',
  'html':'<a href="https://icon.bearlab.eu/" target="_blank">图标获取请戳这里</a>',
  inputPlaceholder: '请填写提示框图标名',
  showCancelButton: true,
  cancelButtonText: "取消", 
  confirmButtonText: '插入',
  inputValidator: (valuefive) => {
      if(!valuefive){
          var icon = '';
      }
      else{
          var icon = ' icon="'+valuefive+'"';
      }
      var text = '[bsmessage type="'+valueone+'" color="'+valuetwo+'" title="'+valuethree+'"'+icon+']'+valuefour+'[/bsmessage]';
      editor.codemirror.doc.replaceSelection(text);
    resolve()
  }
})
        
        
        
        resolve()
    }
  }
})
        
        
        
        resolve() 
      } 
      else{
         resolve('您必须填写提示框标题~~') 
      }
    })
  }
})

        
        
        
        
        
        resolve() 
      } 
      else{
         resolve('您必须选择一款颜色~~') 
      }
    })
  }
})

        
        
        
        
        
        
        
        
        resolve() 
      } 
      else{
         resolve('您必须选择一款提示框~~') 
      }
    })
  }
})

      }
      
       function colorpc(editor){
       Swal.fire({
  title: '字体颜色选择器面板',
  html: "<div id=\"color\"></div><br>选择完颜色后点击下面的直接插入按钮进行应用，本功能实现的效果仅在前台文章内页可见。",
  icon: 'info',
showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  cancelButtonText: "取消", 
  confirmButtonText: '直接插入'
}).then((result) => {
  if (result.isConfirmed) {
  var colorss = document.getElementById("colors").value;
  if(!colorss){
      alert('未选择颜色，不能直接插入!');
  }
  else{
    editor.codemirror.doc.replaceSelection('{bs-font color="'+ colorss + '"}内容{/bs-font}');
  }
  }
})
       $('#color').colorpicker({
        popover: false,
        inline: true,
        container: '#color',
template: '<div class="colorpicker">' +
          '<div class="colorpicker-saturation"><i class="colorpicker-guide"></i></div>' +
          '<div class="colorpicker-hue"><i class="colorpicker-guide"></i></div>' +
          '<div class="colorpicker-alpha">' +
          '   <div class="colorpicker-alpha-color"></div>' +
          '   <i class="colorpicker-guide"></i>' +
          '</div>' +
          '<div class="colorpicker-bar">' +
          '   <div class="input-group">' +
          '       <input id="colors" class="form-control input-block color-io" />' +
          '   </div>' +
          '</div>' +
          '</div>'
        })
        .on('colorpickerCreate', function (e) {
          var io = e.colorpicker.element.find('.color-io');
          io.val(e.color.string());
          io.on('change keyup', function () {
            e.colorpicker.setValue(io.val());
          });
        })
        .on('colorpickerChange', function (e) {
          var io = e.colorpicker.element.find('.color-io');
          if (e.value === io.val() || !e.color || !e.color.isValid()) {
            return;
          }
          io.val(e.color.string());
        });
       }
       $(document).ready(function() {
               $(".copyupload").attr("style","display:none;");
               $(".insertper").attr("style","display:none;");
               $(".autosaves").attr("style","display:none;");
               localStorage.setItem('autosavecid','');
        
       });
     

      
        </script>
        <?php
    }
if($options->editor == '1' || empty($options->editor)){
?>
		<style>.wmd-button-row {
    height: auto;
}</style>
<link rel="stylesheet" href="//cdn.staticfile.org/font-awesome/4.7.0/css/font-awesome.min.css" />
<link rel="stylesheet" href="//cdn.staticfile.org/limonte-sweetalert2/11.3.10/sweetalert2.min.css" />
<link href="//deliver.application.pub/npm/@sweetalert2/theme-bootstrap-4/bootstrap-4.css" rel="stylesheet">
<link rel="stylesheet" href="//cdn.staticfile.org/bootstrap-colorpicker/3.4.0/css/bootstrap-colorpicker.min.css" />
<script src="//cdn.staticfile.org/limonte-sweetalert2/11.3.10/sweetalert2.min.js"></script>
        <script type="text/javascript" src="//cdn.staticfile.org/bootstrap-colorpicker/3.4.0/js/bootstrap-colorpicker.min.js"></script>
		 <script> 
          $(document).ready(function(){
          	$('#wmd-button-row').append('<li class="wmd-button" id="wmd-loginkj-button" title="登录后可见"><span style="background: none;margin-top:5px;font-size: large;text-align: center;color: #999999;font-family: serif;"><i class="fa fa-user-circle"></i></span></li>');
				if($('#wmd-button-row').length !== 0){
					$('#wmd-loginkj-button').click(function(){
						var rs = "[bslogin]隐藏内容[/bslogin]";
						loginkj(rs);
					})
				}


				function loginkj(tag) {
					var myField;
					if (document.getElementById('text') && document.getElementById('text').type == 'textarea') {
						myField = document.getElementById('text');
					} else {
						return false;
					}
					if (document.selection) {
						myField.focus();
						sel = document.selection.createRange();
						sel.text = tag;
						myField.focus();
					}
					else if (myField.selectionStart || myField.selectionStart == '0') {
						var startPos = myField.selectionStart;
						var endPos = myField.selectionEnd;
						var cursorPos = startPos;
						myField.value = myField.value.substring(0, startPos)
						+ tag
						+ myField.value.substring(endPos, myField.value.length);
						cursorPos += tag.length;
						myField.focus();
						myField.selectionStart = cursorPos;
						myField.selectionEnd = cursorPos;
					} else {
						myField.value += tag;
						myField.focus();
					}
				}

				

			});
</script>
		<script> 
          $(document).ready(function(){
          	$('#wmd-button-row').append('<li class="wmd-button" id="wmd-hfkj-button" title="回复或登录后可见"><span style="background: none;margin-top:5px;font-size: large;text-align: center;color: #999999;font-family: serif;"><i class="fa fa-commenting"></i></span></li>');
				if($('#wmd-button-row').length !== 0){
					$('#wmd-hfkj-button').click(function(){
						var rs = "[bshide]隐藏内容[/bshide]";
						hfkj(rs);
					})
				}


				function hfkj(tag) {
					var myField;
					if (document.getElementById('text') && document.getElementById('text').type == 'textarea') {
						myField = document.getElementById('text');
					} else {
						return false;
					}
					if (document.selection) {
						myField.focus();
						sel = document.selection.createRange();
						sel.text = tag;
						myField.focus();
					}
					else if (myField.selectionStart || myField.selectionStart == '0') {
						var startPos = myField.selectionStart;
						var endPos = myField.selectionEnd;
						var cursorPos = startPos;
						myField.value = myField.value.substring(0, startPos)
						+ tag
						+ myField.value.substring(endPos, myField.value.length);
						cursorPos += tag.length;
						myField.focus();
						myField.selectionStart = cursorPos;
						myField.selectionEnd = cursorPos;
					} else {
						myField.value += tag;
						myField.focus();
					}
				}

				

			});
</script>

<script> 
          $(document).ready(function(){
          	$('#wmd-button-row').append('<li class="wmd-button" id="wmd-todocheck-button" title="打勾已完成"><span style="background: none;margin-top:5px;font-size: large;text-align: center;color: #999999;font-family: serif;"><i class="fa fa-check-square"></i></span></li>');
				if($('#wmd-button-row').length !== 0){
					$('#wmd-todocheck-button').click(function(){
						var rs = "[todo-t]Todolist已完成的内容[/todo-t]";
						todocheck(rs);
					})
				}


				function todocheck(tag) {
					var myField;
					if (document.getElementById('text') && document.getElementById('text').type == 'textarea') {
						myField = document.getElementById('text');
					} else {
						return false;
					}
					if (document.selection) {
						myField.focus();
						sel = document.selection.createRange();
						sel.text = tag;
						myField.focus();
					}
					else if (myField.selectionStart || myField.selectionStart == '0') {
						var startPos = myField.selectionStart;
						var endPos = myField.selectionEnd;
						var cursorPos = startPos;
						myField.value = myField.value.substring(0, startPos)
						+ tag
						+ myField.value.substring(endPos, myField.value.length);
						cursorPos += tag.length;
						myField.focus();
						myField.selectionStart = cursorPos;
						myField.selectionEnd = cursorPos;
					} else {
						myField.value += tag;
						myField.focus();
					}
				}
			});
</script>
<script> 
          $(document).ready(function(){
          	$('#wmd-button-row').append('<li class="wmd-button" id="wmd-todonotcheck-button" title="打叉未完成"><span style="background: none;margin-top:5px;font-size: large;text-align: center;color: #999999;font-family: serif;"><i class="fa fa-square"></i></span></li>');
				if($('#wmd-button-row').length !== 0){
					$('#wmd-todonotcheck-button').click(function(){
						var rs = "[todo-f]Todolist待完成的内容[/todo-f];
						todonotcheck(rs);
					})
				}


				function todonotcheck(tag) {
					var myField;
					if (document.getElementById('text') && document.getElementById('text').type == 'textarea') {
						myField = document.getElementById('text');
					} else {
						return false;
					}
					if (document.selection) {
						myField.focus();
						sel = document.selection.createRange();
						sel.text = tag;
						myField.focus();
					}
					else if (myField.selectionStart || myField.selectionStart == '0') {
						var startPos = myField.selectionStart;
						var endPos = myField.selectionEnd;
						var cursorPos = startPos;
						myField.value = myField.value.substring(0, startPos)
						+ tag
						+ myField.value.substring(endPos, myField.value.length);
						cursorPos += tag.length;
						myField.focus();
						myField.selectionStart = cursorPos;
						myField.selectionEnd = cursorPos;
					} else {
						myField.value += tag;
						myField.focus();
					}
				}
			});
</script>
<script> 
          $(document).ready(function(){
          	$('#wmd-button-row').append('<li class="wmd-button" id="wmd-codes-button" title="代码高亮"><span style="background: none;margin-top:5px;font-size: large;text-align: center;color: #999999;font-family: serif;"><svg t="1632126906909" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2425" width="16" height="16"><path d="M298.900577 778.338974c-7.070023 7.070023-17.974373 7.070023-25.043373 0L20.039405 524.521175c-7.070023-7.070023-7.070023-17.974373 0-25.043373l253.8178-253.8178c7.070023-7.070023 17.974373-7.070023 25.043373 0l27.242458 27.242458c7.070023 7.070023 7.070023 17.974373 0 25.043373L112.089891 512l214.053144 214.053144c7.070023 7.070023 7.070023 17.974373 0 25.043373L298.900577 778.338974zM444.87316 873.098151c-2.726088 9.269108-12.522198 14.702863-21.24486 11.995195l-33.767058-9.269108c-9.250688-2.726088-14.702863-12.522198-11.976776-21.790282l203.148793-703.132108c2.726088-9.269108 12.522198-14.702863 21.24486-11.995195l33.767058 9.269108c9.250688 2.726088 14.702863 12.522198 11.976776 21.790282L444.87316 873.098151zM752.049215 778.338974c-7.070023 7.070023-17.974373 7.070023-25.043373 0l-27.242458-27.242458c-7.070023-7.070023-7.070023-17.974373 0-25.043373l214.053144-214.053144L699.763384 297.946856c-7.070023-7.070023-7.070023-17.974373 0-25.043373l27.242458-27.242458c7.070023-7.070023 17.974373-7.070023 25.043373 0l253.8178 253.8178c7.070023 7.070023 7.070023 17.974373 0 25.043373L752.049215 778.338974z" p-id="2426" fill="#707070"></path></svg></span></li>');
				if($('#wmd-button-row').length !== 0){
					$('#wmd-codes-button').click(function(){
						var rs = "```编程语言\n这里是内容\n```";
						codes(rs);
					})
				}


				function codes(tag) {
					var myField;
					if (document.getElementById('text') && document.getElementById('text').type == 'textarea') {
						myField = document.getElementById('text');
					} else {
						return false;
					}
					if (document.selection) {
						myField.focus();
						sel = document.selection.createRange();
						sel.text = tag;
						myField.focus();
					}
					else if (myField.selectionStart || myField.selectionStart == '0') {
						var startPos = myField.selectionStart;
						var endPos = myField.selectionEnd;
						var cursorPos = startPos;
						myField.value = myField.value.substring(0, startPos)
						+ tag
						+ myField.value.substring(endPos, myField.value.length);
						cursorPos += tag.length;
						myField.focus();
						myField.selectionStart = cursorPos;
						myField.selectionEnd = cursorPos;
					} else {
						myField.value += tag;
						myField.focus();
					}
				}
			});
</script>
<script> 
          $(document).ready(function(){
          	$('#wmd-button-row').append('<li class="wmd-button" id="wmd-fontcolor-button" title="字体颜色"><span style="background: none;margin-top:5px;font-size: large;text-align: center;color: #999999;font-family: serif;"><i class="fa fa-font"></i></span></li>');
				if($('#wmd-button-row').length !== 0){
					$('#wmd-fontcolor-button').click(function(){
						Swal.fire({
  title: '字体颜色选择器面板',
  html: "<div id=\"color\"></div><br>选择完颜色后点击下面的直接插入按钮进行应用，本功能实现的效果仅在前台文章内页可见。",
  icon: 'info',
showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  cancelButtonText: "取消", 
  confirmButtonText: '直接插入'
}).then((result) => {
  if (result.isConfirmed) {
  var colorss = document.getElementById("colors").value;
  if(!colorss){
      alert('未选择颜色，不能直接插入!');
  }
  else{
    fontcolor('{bs-font color="'+ colorss + '"}内容{/bs-font}');
  }
  }
})
       $('#color').colorpicker({
        popover: false,
        inline: true,
        container: '#color',
template: '<div class="colorpicker">' +
          '<div class="colorpicker-saturation"><i class="colorpicker-guide"></i></div>' +
          '<div class="colorpicker-hue"><i class="colorpicker-guide"></i></div>' +
          '<div class="colorpicker-alpha">' +
          '   <div class="colorpicker-alpha-color"></div>' +
          '   <i class="colorpicker-guide"></i>' +
          '</div>' +
          '<div class="colorpicker-bar">' +
          '   <div class="input-group">' +
          '       <input id="colors" class="form-control input-block color-io" />' +
          '   </div>' +
          '</div>' +
          '</div>'
        })
        .on('colorpickerCreate', function (e) {
          var io = e.colorpicker.element.find('.color-io');
          io.val(e.color.string());
          io.on('change keyup', function () {
            e.colorpicker.setValue(io.val());
          });
        })
        .on('colorpickerChange', function (e) {
          var io = e.colorpicker.element.find('.color-io');
          if (e.value === io.val() || !e.color || !e.color.isValid()) {
            return;
          }
          io.val(e.color.string());
        });
						
					})
				}


				function fontcolor(tag) {
					var myField;
					if (document.getElementById('text') && document.getElementById('text').type == 'textarea') {
						myField = document.getElementById('text');
					} else {
						return false;
					}
					if (document.selection) {
						myField.focus();
						sel = document.selection.createRange();
						sel.text = tag;
						myField.focus();
					}
					else if (myField.selectionStart || myField.selectionStart == '0') {
						var startPos = myField.selectionStart;
						var endPos = myField.selectionEnd;
						var cursorPos = startPos;
						myField.value = myField.value.substring(0, startPos)
						+ tag
						+ myField.value.substring(endPos, myField.value.length);
						cursorPos += tag.length;
						myField.focus();
						myField.selectionStart = cursorPos;
						myField.selectionEnd = cursorPos;
					} else {
						myField.value += tag;
						myField.focus();
					}
				}
			});
</script>
<script> 
          $(document).ready(function(){
          	$('#wmd-button-row').append('<li class="wmd-button" id="wmd-iframe-button" title="插入iframe"><span style="background: none;margin-top:5px;font-size: large;text-align: center;color: #999999;font-family: serif;"><i class="fa fa-window-maximize"></i></span></li>');
				if($('#wmd-button-row').length !== 0){
					$('#wmd-iframe-button').click(function(){
						var rs = "{bs-iframe}iframe地址{/bs-iframe}";
						iframe(rs);
					})
				}


				function iframe(tag) {
					var myField;
					if (document.getElementById('text') && document.getElementById('text').type == 'textarea') {
						myField = document.getElementById('text');
					} else {
						return false;
					}
					if (document.selection) {
						myField.focus();
						sel = document.selection.createRange();
						sel.text = tag;
						myField.focus();
					}
					else if (myField.selectionStart || myField.selectionStart == '0') {
						var startPos = myField.selectionStart;
						var endPos = myField.selectionEnd;
						var cursorPos = startPos;
						myField.value = myField.value.substring(0, startPos)
						+ tag
						+ myField.value.substring(endPos, myField.value.length);
						cursorPos += tag.length;
						myField.focus();
						myField.selectionStart = cursorPos;
						myField.selectionEnd = cursorPos;
					} else {
						myField.value += tag;
						myField.focus();
					}
				}
			});
</script>
<script> 
          $(document).ready(function(){
          	$('#wmd-button-row').append('<li class="wmd-button" id="wmd-audio-button" title="插入音频"><span style="background: none;margin-top:5px;font-size: large;text-align: center;color: #999999;font-family: serif;"><i class="fa fa-file-audio-o"></i></span></li>');
				if($('#wmd-button-row').length !== 0){
					$('#wmd-audio-button').click(function(){
						var rs = "[bsaudio]音频地址[/bsaudio]";
						audio(rs);
					})
				}


				function audio(tag) {
					var myField;
					if (document.getElementById('text') && document.getElementById('text').type == 'textarea') {
						myField = document.getElementById('text');
					} else {
						return false;
					}
					if (document.selection) {
						myField.focus();
						sel = document.selection.createRange();
						sel.text = tag;
						myField.focus();
					}
					else if (myField.selectionStart || myField.selectionStart == '0') {
						var startPos = myField.selectionStart;
						var endPos = myField.selectionEnd;
						var cursorPos = startPos;
						myField.value = myField.value.substring(0, startPos)
						+ tag
						+ myField.value.substring(endPos, myField.value.length);
						cursorPos += tag.length;
						myField.focus();
						myField.selectionStart = cursorPos;
						myField.selectionEnd = cursorPos;
					} else {
						myField.value += tag;
						myField.focus();
					}
				}
			});
</script>
<script> 
          $(document).ready(function(){
          	$('#wmd-button-row').append('<li class="wmd-button" id="wmd-star-button" title="插入评星"><span style="background: none;margin-top:5px;font-size: large;text-align: center;color: #999999;font-family: serif;"><i class="fa fa-star-half-o"></i></span></li>');
				if($('#wmd-button-row').length !== 0){
					$('#wmd-star-button').click(function(){
						Swal.fire({
  title: '第一步 选择评星样式',
  input: 'select',
  inputOptions: {
      'star': '星星',
      'heart': '红心',
  },
  inputPlaceholder: '选择一款样式',
  showCancelButton: true,
cancelButtonText: "取消", 
  confirmButtonText: '下一步',
  inputValidator: (valueone) => {
    return new Promise((resolve) => {
      if (valueone !== '') {

                Swal.fire({
  title: '第二步 输入评星数目',
  input: 'number',
inputLabel: '输入评星数目，最高五颗星',
inputAttributes:{
  min:1,
  max:5,
  
},
  inputPlaceholder: '输入评星数目',
  showCancelButton: true,
cancelButtonText: "取消", 
  confirmButtonText: '插入',
  inputValidator: (valuetwo) => {
    return new Promise((resolve) => {
      if (valuetwo !== '') {
var text = '[bseva type="'+valueone+'"]'+valuetwo+'[/bseva]';
      star(text);
        
        resolve() 
      } 
      else{
         resolve('您必须输入评星数目~~') 
      }
    })
  }
})

        
    
        resolve() 
      } 
      else{
         resolve('您必须选择一款评星样式~~') 
      }
    })
  }
})
					})
				}


				function star(tag) {
					var myField;
					if (document.getElementById('text') && document.getElementById('text').type == 'textarea') {
						myField = document.getElementById('text');
					} else {
						return false;
					}
					if (document.selection) {
						myField.focus();
						sel = document.selection.createRange();
						sel.text = tag;
						myField.focus();
					}
					else if (myField.selectionStart || myField.selectionStart == '0') {
						var startPos = myField.selectionStart;
						var endPos = myField.selectionEnd;
						var cursorPos = startPos;
						myField.value = myField.value.substring(0, startPos)
						+ tag
						+ myField.value.substring(endPos, myField.value.length);
						cursorPos += tag.length;
						myField.focus();
						myField.selectionStart = cursorPos;
						myField.selectionEnd = cursorPos;
					} else {
						myField.value += tag;
						myField.focus();
					}
				}
			});
</script>
<script> 
          $(document).ready(function(){
          	$('#wmd-button-row').append('<li class="wmd-button" id="wmd-accord1-button" title="插入线性手风琴"><span style="background: none;margin-top:5px;font-size: large;text-align: center;color: #999999;font-family: serif;"><i class="fa fa-plus-square"></i></span></li>');
				if($('#wmd-button-row').length !== 0){
					$('#wmd-accord1-button').click(function(){
						var rs = "{bs-accord style=line title=线性手风琴标题}线性手风琴内容{/bs-accord}";
						accord1(rs);
					})
				}


				function accord1(tag) {
					var myField;
					if (document.getElementById('text') && document.getElementById('text').type == 'textarea') {
						myField = document.getElementById('text');
					} else {
						return false;
					}
					if (document.selection) {
						myField.focus();
						sel = document.selection.createRange();
						sel.text = tag;
						myField.focus();
					}
					else if (myField.selectionStart || myField.selectionStart == '0') {
						var startPos = myField.selectionStart;
						var endPos = myField.selectionEnd;
						var cursorPos = startPos;
						myField.value = myField.value.substring(0, startPos)
						+ tag
						+ myField.value.substring(endPos, myField.value.length);
						cursorPos += tag.length;
						myField.focus();
						myField.selectionStart = cursorPos;
						myField.selectionEnd = cursorPos;
					} else {
						myField.value += tag;
						myField.focus();
					}
				}
			});
</script>
<script> 
          $(document).ready(function(){
          	$('#wmd-button-row').append('<li class="wmd-button" id="wmd-accord2-button" title="插入普通手风琴"><span style="background: none;margin-top:5px;font-size: large;text-align: center;color: #999999;font-family: serif;"><i class="fa fa-plus-square-o"></i></span></li>');
				if($('#wmd-button-row').length !== 0){
					$('#wmd-accord2-button').click(function(){
						var rs = "{bs-accord style=common title=普通手风琴标题}普通手风琴内容{/bs-accord}";
						accord2(rs);
					})
				}


				function accord2(tag) {
					var myField;
					if (document.getElementById('text') && document.getElementById('text').type == 'textarea') {
						myField = document.getElementById('text');
					} else {
						return false;
					}
					if (document.selection) {
						myField.focus();
						sel = document.selection.createRange();
						sel.text = tag;
						myField.focus();
					}
					else if (myField.selectionStart || myField.selectionStart == '0') {
						var startPos = myField.selectionStart;
						var endPos = myField.selectionEnd;
						var cursorPos = startPos;
						myField.value = myField.value.substring(0, startPos)
						+ tag
						+ myField.value.substring(endPos, myField.value.length);
						cursorPos += tag.length;
						myField.focus();
						myField.selectionStart = cursorPos;
						myField.selectionEnd = cursorPos;
					} else {
						myField.value += tag;
						myField.focus();
					}
				}
			});
</script>
<script> 
          $(document).ready(function(){
          	$('#wmd-button-row').append('<li class="wmd-button" id="wmd-message-button" title="插入提示框"><span style="background: none;margin-top:5px;font-size: large;text-align: center;color: #999999;font-family: serif;"><i class="fa fa-sticky-note-o"></i></span></li>');
				if($('#wmd-button-row').length !== 0){
					$('#wmd-message-button').click(function(){
						Swal.fire({
  title: '第一步 选择提示框样式',
  input: 'select',
  inputOptions: {
      'common': '普通提示框',
      'basic': '阴影提示框',
      'commonclose': '普通可关闭提示框',
      'basicclose':'阴影可关闭提示框',
  },
  inputPlaceholder: '选择一款提示框',
  showCancelButton: true,
cancelButtonText: "取消", 
  confirmButtonText: '下一步',
  inputValidator: (valueone) => {
    return new Promise((resolve) => {
      if (valueone !== '') {

                Swal.fire({
  title: '第二步 选择提示框颜色',
  input: 'select',
  inputOptions: {
      'standard': '淡色',
      'info':'淡青色',
      'primary': '蓝色',
      'secondary': '黑色',
      'red': '红色',
      'orange': '橙色',
      'yellow': '黄色',
      'olive': '淡绿色',
      'green': '深绿色',
      'teal': '青色',
      'violet': '紫罗兰色',
      'purple': '基佬紫色',
      'pink': '粉色',
      'brown': '土黄色',
      'grey': '灰色',
  },
  inputPlaceholder: '选择一款颜色',
  showCancelButton: true,
cancelButtonText: "取消", 
  confirmButtonText: '下一步',
  inputValidator: (valuetwo) => {
    return new Promise((resolve) => {
      if (valuetwo !== '') {
        
        

  Swal.fire({
      title: '第三步 填写提示框标题',
  input: 'text',
  inputLabel: '提示框标题',
  inputPlaceholder: '填写提示框标题',
    showCancelButton: true,
cancelButtonText: "取消", 
  confirmButtonText: '下一步',
  inputValidator: (valuethree) => {
    return new Promise((resolve) => {
      if (valuethree !== '') {
        
        
        Swal.fire({
  title: '第四步 填写提示框内容',
  input: 'textarea',
  inputLabel: '提示框内容',
  inputPlaceholder: '请填写提示框内容',
  showCancelButton: true,
  cancelButtonText: "取消", 
  confirmButtonText: '下一步',
  inputValidator: (valuefour) => {
    if (!valuefour) {
      return '您必须填写提示框内容'
    }
    else{
        
        
        
        Swal.fire({
  title: '第五步 填写提示框图标名',
  input: 'text',
  inputLabel: '提示框图标名(若不需要图标可留空)',
  'html':'<a href="https://icon.bearlab.eu/" target="_blank">图标获取请戳这里</a>',
  inputPlaceholder: '请填写提示框图标名',
  showCancelButton: true,
  cancelButtonText: "取消", 
  confirmButtonText: '插入',
  inputValidator: (valuefive) => {
      if(!valuefive){
          var icon = '';
      }
      else{
          var icon = ' icon="'+valuefive+'"';
      }
      var text = '[bsmessage type="'+valueone+'" color="'+valuetwo+'" title="'+valuethree+'"'+icon+']'+valuefour+'[/bsmessage]';
      message(text);
    resolve()
  }
})
        
        
        
        resolve()
    }
  }
})
        
        
        
        resolve() 
      } 
      else{
         resolve('您必须填写提示框标题~~') 
      }
    })
  }
})

        
        
        
        
        
        resolve() 
      } 
      else{
         resolve('您必须选择一款颜色~~') 
      }
    })
  }
})

        
        
        
        
        
        
        
        
        resolve() 
      } 
      else{
         resolve('您必须选择一款提示框~~') 
      }
    })
  }
})
					})
				}


				function message(tag) {
					var myField;
					if (document.getElementById('text') && document.getElementById('text').type == 'textarea') {
						myField = document.getElementById('text');
					} else {
						return false;
					}
					if (document.selection) {
						myField.focus();
						sel = document.selection.createRange();
						sel.text = tag;
						myField.focus();
					}
					else if (myField.selectionStart || myField.selectionStart == '0') {
						var startPos = myField.selectionStart;
						var endPos = myField.selectionEnd;
						var cursorPos = startPos;
						myField.value = myField.value.substring(0, startPos)
						+ tag
						+ myField.value.substring(endPos, myField.value.length);
						cursorPos += tag.length;
						myField.focus();
						myField.selectionStart = cursorPos;
						myField.selectionEnd = cursorPos;
					} else {
						myField.value += tag;
						myField.focus();
					}
				}
			});
</script>
<script> 
          $(document).ready(function(){
          	$('#wmd-button-row').append('<li class="wmd-button" id="wmd-button-button" title="插入按钮"><span style="background: none;margin-top:5px;font-size: large;text-align: center;color: #999999;font-family: serif;"><i class="fa fa-circle-o-notch"></i></span></li>');
				if($('#wmd-button-row').length !== 0){
					$('#wmd-button-button').click(function(){
						Swal.fire({
  title: '第一步 选择按钮样式',
  input: 'select',
  inputOptions: {
      'common': '普通按钮',
      'basic': '光圈按钮',
      'animated': '动画按钮',
  },
  inputPlaceholder: '选择一款按钮',
  showCancelButton: true,
cancelButtonText: "取消", 
  confirmButtonText: '下一步',
  inputValidator: (valueone) => {
    return new Promise((resolve) => {
      if (valueone !== '') {

                Swal.fire({
  title: '第二步 选择按钮颜色',
  input: 'select',
  inputOptions: {
      'standard': '淡色',
      'primary': '蓝色',
      'secondary': '黑色',
      'red': '红色',
      'orange': '橙色',
      'yellow': '黄色',
      'olive': '淡绿色',
      'green': '深绿色',
      'teal': '青色',
      'violet': '紫罗兰色',
      'purple': '基佬紫色',
      'pink': '粉色',
      'brown': '土黄色',
      'grey': '灰色',
  },
  inputPlaceholder: '选择一款颜色',
  showCancelButton: true,
cancelButtonText: "取消", 
  confirmButtonText: '下一步',
  inputValidator: (valuetwo) => {
    return new Promise((resolve) => {
      if (valuetwo !== '') {
        
        

  Swal.fire({
      title: '第三步 填写按钮点击链接',
  input: 'url',
  inputLabel: '按钮点击跳转链接',
  inputPlaceholder: '填写按钮点击跳转链接，需带http(s)://',
    showCancelButton: true,
cancelButtonText: "取消", 
  confirmButtonText: '下一步',
  inputValidator: (valuethree) => {
    return new Promise((resolve) => {
      if (valuethree !== '') {
        
        
        Swal.fire({
  title: '第四步 填写按钮名称',
  input: 'text',
  inputLabel: '按钮名称(若为动画按钮，两个名称请使用|隔开)',
  inputPlaceholder: '请填写按钮名称',
  showCancelButton: true,
  cancelButtonText: "取消", 
  confirmButtonText: '下一步',
  inputValidator: (valuefour) => {
    if (!valuefour) {
      return '您必须填写按钮名称'
    }
    else{
        
        
        
        Swal.fire({
  title: '第五步 填写按钮图标名',
  input: 'text',
  inputLabel: '按钮图标名(若不需要图标可留空)',
  'html':'<a href="https://icon.bearlab.eu/" target="_blank">图标获取请戳这里</a>',
  inputPlaceholder: '请填写按钮图标名',
  showCancelButton: true,
  cancelButtonText: "取消", 
  confirmButtonText: '插入',
  inputValidator: (valuefive) => {
      if(!valuefive){
          var icon = '';
      }
      else{
          var icon = ' icon="'+valuefive+'"';
      }
      var text = '[bsbtn type="'+valueone+'" color="'+valuetwo+'" url="'+valuethree+'"'+icon+']'+valuefour+'[/bsbtn]';
      button(text);
    resolve()
  }
})
        
        
        
        resolve()
    }
  }
})
        
        
        
        resolve() 
      } 
      else{
         resolve('您必须填写跳转链接~~') 
      }
    })
  }
})

        
        
        
        
        
        resolve() 
      } 
      else{
         resolve('您必须选择一款颜色~~') 
      }
    })
  }
})

        
        
        
        
        
        
        
        
        resolve() 
      } 
      else{
         resolve('您必须选择一款按钮~~') 
      }
    })
  }
})
					})
				}


				function button(tag) {
					var myField;
					if (document.getElementById('text') && document.getElementById('text').type == 'textarea') {
						myField = document.getElementById('text');
					} else {
						return false;
					}
					if (document.selection) {
						myField.focus();
						sel = document.selection.createRange();
						sel.text = tag;
						myField.focus();
					}
					else if (myField.selectionStart || myField.selectionStart == '0') {
						var startPos = myField.selectionStart;
						var endPos = myField.selectionEnd;
						var cursorPos = startPos;
						myField.value = myField.value.substring(0, startPos)
						+ tag
						+ myField.value.substring(endPos, myField.value.length);
						cursorPos += tag.length;
						myField.focus();
						myField.selectionStart = cursorPos;
						myField.selectionEnd = cursorPos;
					} else {
						myField.value += tag;
						myField.focus();
					}
				}
			});
</script>
 <script> 
          $(document).ready(function(){
          	$('#wmd-button-row').append('<li class="wmd-button" id="wmd-progress-button" title="插入进度条"><span style="background: none;margin-top:5px;font-size: large;text-align: center;color: #999999;font-family: serif;"><i class="fa fa-product-hunt"></i></span></li>');
				if($('#wmd-button-row').length !== 0){
				    $('#wmd-progress-button').click(function(){
				    Swal.fire({
  title: '选择进度条颜色',
  input: 'select',
  inputOptions: {
      'normal':'蓝色',
      'success': '绿色',
      'info': '青色',
      'warning': '黄色',
      'danger': '红色',
      'light': '白色',
      'dark': '黑色',
  },
  inputPlaceholder: '选择一款颜色',
  showCancelButton: true,
cancelButtonText: "取消", 
  confirmButtonText: '下一步',
  inputValidator: (valueone) => {
    return new Promise((resolve) => {
      if (valueone !== '') {
      
      Swal.fire({
      title: '第二步 填写进度条标题',
  input: 'text',
  inputLabel: '进度条标题[将显示在进度条上方]',
  inputPlaceholder: '填写进度条标题',
    showCancelButton: true,
cancelButtonText: "取消", 
  confirmButtonText: '下一步',
  inputValidator: (valuetwo) => {
    return new Promise((resolve) => {
      if (valuetwo !== '') {
             Swal.fire({
      title: '第三步 填写进度条数值',
  input: 'text',
  inputLabel: '进度条数值[如40%就填写40]',
  inputPlaceholder: '填写进度条数值',
    showCancelButton: true,
cancelButtonText: "取消", 
  confirmButtonText: '插入',
  inputValidator: (valuethree) => {
    return new Promise((resolve) => {
      if (valuethree !== '') {
                var text = '[bsprog color="'+valueone+'" number="'+valuethree+'"]'+valuetwo+'[/bsprog]';
      progress(text);
    resolve()
      }
      else{
       resolve('您必须填写进度条数值~')    
      }
    })
  }
})
    resolve()
      }
      else{
       resolve('您必须填写进度条标题~')    
      }
    })
  }
})
      
      
      
      
      } 
      else{
         resolve('您必须选择一款颜色~') 
      }
    })
  }
})

				})
				}


				function progress(tag) {
					var myField;
					if (document.getElementById('text') && document.getElementById('text').type == 'textarea') {
						myField = document.getElementById('text');
					} else {
						return false;
					}
					if (document.selection) {
						myField.focus();
						sel = document.selection.createRange();
						sel.text = tag;
						myField.focus();
					}
					else if (myField.selectionStart || myField.selectionStart == '0') {
						var startPos = myField.selectionStart;
						var endPos = myField.selectionEnd;
						var cursorPos = startPos;
						myField.value = myField.value.substring(0, startPos)
						+ tag
						+ myField.value.substring(endPos, myField.value.length);
						cursorPos += tag.length;
						myField.focus();
						myField.selectionStart = cursorPos;
						myField.selectionEnd = cursorPos;
					} else {
						myField.value += tag;
						myField.focus();
					}
				}
			});
</script>
<script> 
          $(document).ready(function(){
          	$('#wmd-button-row').append('<li class="wmd-button" id="wmd-fujian-button" title="插入所有附件"><span style="background: none;margin-top:5px;font-size: large;text-align: center;color: #999999;font-family: serif;"><i class="fa fa-paperclip"></i></span></li>');
				if($('#wmd-button-row').length !== 0){
					$('#wmd-fujian-button').click(function(){
                 function getData() {
                    $.ajax({
                        type: "GET",
                        url: "<?php getAttachFile(); ?>",
                        data: {
                            "cid": "<?php echo $cid; ?>",
                             "url": "<?php echo $url; ?>",
                        },
                        dateType: "json",
                        success: function(json) {
                            json = JSON.parse(json);
                            content(json.list);
                        },
                        complete: function() {
                        },
                        error: function() {
                            alert("数据获取错误");
                        }
                    });
                }
                getData();
                function content(list) {
                    var filename = " ";
                    var fileurl = " ";
                    for(var i in list) {
                        if(list[i]['type'] == 'img'){
                        filename += '![' + list[i]['title'] + '][' + list[i]['cid'] + ']\n'
fileurl += '\n  [' + list[i]['cid'] + ']:' + list[i]['url']
}
                        if(list[i]['type'] == 'other'){
                        filename += '[' + list[i]['title'] + '][' + list[i]['cid'] + ']\n'
fileurl += '\n  [' + list[i]['cid'] + ']:' + list[i]['url']
}
}
fujian(filename + fileurl);
}
					})
				}


				function fujian(tag) {
					var myField;
					if (document.getElementById('text') && document.getElementById('text').type == 'textarea') {
						myField = document.getElementById('text');
					} else {
						return false;
					}
					if (document.selection) {
						myField.focus();
						sel = document.selection.createRange();
						sel.text = tag;
						myField.focus();
					}
					else if (myField.selectionStart || myField.selectionStart == '0') {
						var startPos = myField.selectionStart;
						var endPos = myField.selectionEnd;
						var cursorPos = startPos;
						myField.value = myField.value.substring(0, startPos)
						+ tag
						+ myField.value.substring(endPos, myField.value.length);
						cursorPos += tag.length;
						myField.focus();
						myField.selectionStart = cursorPos;
						myField.selectionEnd = cursorPos;
					} else {
						myField.value += tag;
						myField.focus();
					}
				}
			});
</script>

<script> 
          $(document).ready(function(){
          	$('#wmd-button-row').append('<li class="wmd-button" id="wmd-bscardgithub-button" title="Github仓库"><span style="background: none;margin-top:5px;font-size: large;text-align: center;color: #999999;font-family: serif;"><i class="fa fa-github"></i></span></li>');
				if($('#wmd-button-row').length !== 0){
					$('#wmd-bscardgithub-button').click(function(){
						var rs = '[bsgit user="Github仓库拥有者，如whitebearcode"]Github项目名，如typecho-bearsimple[/bsgit]';
						githubcard(rs);
					})
				}


				function githubcard(tag) {
					var myField;
					if (document.getElementById('text') && document.getElementById('text').type == 'textarea') {
						myField = document.getElementById('text');
					} else {
						return false;
					}
					if (document.selection) {
						myField.focus();
						sel = document.selection.createRange();
						sel.text = tag;
						myField.focus();
					}
					else if (myField.selectionStart || myField.selectionStart == '0') {
						var startPos = myField.selectionStart;
						var endPos = myField.selectionEnd;
						var cursorPos = startPos;
						myField.value = myField.value.substring(0, startPos)
						+ tag
						+ myField.value.substring(endPos, myField.value.length);
						cursorPos += tag.length;
						myField.focus();
						myField.selectionStart = cursorPos;
						myField.selectionEnd = cursorPos;
					} else {
						myField.value += tag;
						myField.focus();
					}
				}
			});
</script>
<script> 
          $(document).ready(function(){
          	$('#wmd-button-row').append('<li class="wmd-button" id="wmd-gallery-button" title="相册"><span style="background: none;margin-top:5px;font-size: large;text-align: center;color: #999999;font-family: serif;"><i class="fa fa-file-image-o"></i></span></li>');
				if($('#wmd-button-row').length !== 0){
					$('#wmd-gallery-button').click(function(){
						var rs = '[bsgallery title="相册名"]\n[bsimg title="图片标题1" subtitle="图片子标题1"]图片地址1[/bsimg]\n[bsimg title="图片标题2" subtitle="图片子标题2"]图片地址2[/bsimg]\n[bsimg title="图片标题3" subtitle="图片子标题3"]图片地址3[/bsimg]\n[/bsgallery]';
						gallery(rs);
					})
				}


				function gallery(tag) {
					var myField;
					if (document.getElementById('text') && document.getElementById('text').type == 'textarea') {
						myField = document.getElementById('text');
					} else {
						return false;
					}
					if (document.selection) {
						myField.focus();
						sel = document.selection.createRange();
						sel.text = tag;
						myField.focus();
					}
					else if (myField.selectionStart || myField.selectionStart == '0') {
						var startPos = myField.selectionStart;
						var endPos = myField.selectionEnd;
						var cursorPos = startPos;
						myField.value = myField.value.substring(0, startPos)
						+ tag
						+ myField.value.substring(endPos, myField.value.length);
						cursorPos += tag.length;
						myField.focus();
						myField.selectionStart = cursorPos;
						myField.selectionEnd = cursorPos;
					} else {
						myField.value += tag;
						myField.focus();
					}
				}
			});
</script>
<script> 
          $(document).ready(function(){
          	$('#wmd-button-row').append('<li class="wmd-button" id="wmd-quotepost-button" title="引用文章"><span style="background: none;margin-top:5px;font-size: large;text-align: center;color: #999999;font-family: serif;"><i class="fa fa-newspaper-o"></i></span></li>');
				if($('#wmd-button-row').length !== 0){
					$('#wmd-quotepost-button').click(function(){
						var rs = '[bspost cid="文章CID"]';
						quotepost(rs);
					})
				}


				function quotepost(tag) {
					var myField;
					if (document.getElementById('text') && document.getElementById('text').type == 'textarea') {
						myField = document.getElementById('text');
					} else {
						return false;
					}
					if (document.selection) {
						myField.focus();
						sel = document.selection.createRange();
						sel.text = tag;
						myField.focus();
					}
					else if (myField.selectionStart || myField.selectionStart == '0') {
						var startPos = myField.selectionStart;
						var endPos = myField.selectionEnd;
						var cursorPos = startPos;
						myField.value = myField.value.substring(0, startPos)
						+ tag
						+ myField.value.substring(endPos, myField.value.length);
						cursorPos += tag.length;
						myField.focus();
						myField.selectionStart = cursorPos;
						myField.selectionEnd = cursorPos;
					} else {
						myField.value += tag;
						myField.focus();
					}
				}
			});
</script>
<script> 
          $(document).ready(function(){
          	$('#wmd-button-row').append('<li class="wmd-button" id="wmd-postmark-button" title="标注文字"><span style="background: none;margin-top:5px;font-size: large;text-align: center;color: #999999;font-family: serif;"><i class="fa fa-bookmark-o"></i></span></li>');
				if($('#wmd-button-row').length !== 0){
					$('#wmd-postmark-button').click(function(){
						var rs = '[bsmark]要标注的内容[/bsmark]';
						postmark(rs);
					})
				}


				function postmark(tag) {
					var myField;
					if (document.getElementById('text') && document.getElementById('text').type == 'textarea') {
						myField = document.getElementById('text');
					} else {
						return false;
					}
					if (document.selection) {
						myField.focus();
						sel = document.selection.createRange();
						sel.text = tag;
						myField.focus();
					}
					else if (myField.selectionStart || myField.selectionStart == '0') {
						var startPos = myField.selectionStart;
						var endPos = myField.selectionEnd;
						var cursorPos = startPos;
						myField.value = myField.value.substring(0, startPos)
						+ tag
						+ myField.value.substring(endPos, myField.value.length);
						cursorPos += tag.length;
						myField.focus();
						myField.selectionStart = cursorPos;
						myField.selectionEnd = cursorPos;
					} else {
						myField.value += tag;
						myField.focus();
					}
				}
			});
</script>
<script> 
          $(document).ready(function(){
          	$('#wmd-button-row').append('<li class="wmd-button" id="wmd-postruby-button" title="文字带拼音"><span style="background: none;margin-top:5px;font-size: large;text-align: center;color: #999999;font-family: serif;"><i class="fa fa-file-word-o"></i></span></li>');
				if($('#wmd-button-row').length !== 0){
					$('#wmd-postruby-button').click(function(){
						var rs = '[bsruby]要带拼音的汉字[/bsruby]';
						postruby(rs);
					})
				}


				function postruby(tag) {
					var myField;
					if (document.getElementById('text') && document.getElementById('text').type == 'textarea') {
						myField = document.getElementById('text');
					} else {
						return false;
					}
					if (document.selection) {
						myField.focus();
						sel = document.selection.createRange();
						sel.text = tag;
						myField.focus();
					}
					else if (myField.selectionStart || myField.selectionStart == '0') {
						var startPos = myField.selectionStart;
						var endPos = myField.selectionEnd;
						var cursorPos = startPos;
						myField.value = myField.value.substring(0, startPos)
						+ tag
						+ myField.value.substring(endPos, myField.value.length);
						cursorPos += tag.length;
						myField.focus();
						myField.selectionStart = cursorPos;
						myField.selectionEnd = cursorPos;
					} else {
						myField.value += tag;
						myField.focus();
					}
				}
			});
</script>
<?php
}
}
    
    /**
     * 回复可见 Replyview
     * Date:29/12/2021
     *
     * @access public
     * @return void
     */ 
      public static function get_shortcode_regex($tagnames = null)
    {
        global $shortcode_tags;
        if (empty($tagnames)) {
            $tagnames = array_keys($shortcode_tags);
        }
        $tagregexp = join('|', array_map('preg_quote', $tagnames));
        return
            '\\['                           
            . '(\\[?)'                        
            . "($tagregexp)"       
            . '(?![\\w-])'                    
            . '('                         
            . '[^\\]\\/]*'               
            . '(?:'
            . '\\/(?!\\])'     
            . '[^\\]\\/]*'          
            . ')*?'
            . ')'
            . '(?:'
            . '(\\/)'                    
            . '\\]'           
            . '|'
            . '\\]'              
            . '(?:'
            . '('       
            . '[^\\[]*+'  
            . '(?:'
            . '\\[(?!\\/\\2\\])'
            . '[^\\[]*+'
            . ')*+'
            . ')'
            . '\\[\\/\\2\\]'    
            . ')?'
            . ')'
            . '(\\]?)'; 
    }

public static function get_shortcode_regex2($tagnames = null)
    {
        global $shortcode_tags;
        if (empty($tagnames)) {
            $tagnames = array_keys($shortcode_tags);
        }
        $tagregexp = join('|', array_map('preg_quote', $tagnames));
        return
            '\\{'                           
            . '(\\[?)'                        
            . "($tagregexp)"       
            . '(?![\\w-])'                    
            . '('                         
            . '[^\\]\\/]*'               
            . '(?:'
            . '\\/(?!\\])'     
            . '[^\\]\\/]*'          
            . ')*?'
            . ')'
            . '(?:'
            . '(\\/)'                    
            . '\\}'           
            . '|'
            . '\\}'              
            . '(?:'
            . '('       
            . '[^\\[]*+'  
            . '(?:'
            . '\\[(?!\\/\\2\\])'
            . '[^\\[]*+'
            . ')*+'
            . ')'
            . '\\[\\/\\2\\}'    
            . ')?'
            . ')'
            . '(\\]?)'; 
    }
    
  public static function one($con,$obj,$text)
    {
      $text = empty($text)?$con:$text;
      if(!$obj->is('single') && strpos($text, '{bs-hide') !== false){
      $text = '文章包含隐藏内容，请进入文章内页查看~';
      }
      if(!$obj->is('single') && strpos($text, '[bs-hide') !== false){
      $text = '文章包含隐藏内容，请进入文章内页查看~';
      }
      if(!$obj->is('single') && strpos($text, '[bshide') !== false){
      $text = '文章包含隐藏内容，请进入文章内页查看~';
      }
      if(!$obj->is('single') && strpos($text, '[bslogin') !== false){
      $text = '文章包含隐藏内容，请进入文章内页查看~';
      }
      if(!$obj->is('single')){
          if (strpos($text, '[bspost') !== false) {
                    $text = preg_replace('/\[bspost (.*?)\]/sm', '', $text);
}
if (strpos($text, '[bsprog') !== false) {
            $pattern = self::get_shortcode_regex(array('bsprog'));
            $text = preg_replace("/$pattern/", '', $text);
        }
         if (strpos($text, '[bsgallery') !== false) {
            $pattern = self::get_shortcode_regex(array('bsgallery'));
            $text = preg_replace("/$pattern/", '', $text);
        }
          if (strpos($text, '[bsgit') !== false) {
            $pattern = self::get_shortcode_regex(array('bsgit'));
            $text = preg_replace("/$pattern/", '', $text);
        }
        if (strpos($text, '[bseva') !== false) {
            $pattern = self::get_shortcode_regex(array('bseva'));
            $text = preg_replace("/$pattern/", '', $text);
        }
        if (strpos($text, '[bsaudio') !== false) {
            $pattern = self::get_shortcode_regex(array('bsaudio'));
            $text = preg_replace("/$pattern/", '', $text);
        }
        if (strpos($content, '[bspost') !== false) {
            $pattern = self::get_shortcode_regex(array('bspost'));
            $text = preg_replace("/$pattern/", '', $text);
        }
        if (strpos($text, '[bsruby') !== false) {
            $pattern = self::get_shortcode_regex(array('bsruby'));
            $text = preg_replace("/$pattern/", '', $text);
        }
        if (strpos($text, '[bsmark') !== false) {
            $pattern = self::get_shortcode_regex(array('bsmark'));
            $text = preg_replace("/$pattern/", '', $text);
        }
        if (strpos($text, '[bsbtn') !== false) {
            $pattern = self::get_shortcode_regex(array('bsbtn'));
            $text = preg_replace("/$pattern/", '', $text);
        }
        if (strpos($text, '[bsmessage') !== false) {
            $pattern = self::get_shortcode_regex(array('bsmessage'));
            $text = preg_replace("/$pattern/", '', $text);
        }
        if (strpos($text, '{bs-todo') !== false) {
            $pattern = self::get_shortcode_regex2(array('bs-todo'));
            $text = preg_replace("/$pattern/", '', $text);
        }
        if (strpos($text, '[todo-t') !== false) {
            $pattern = self::get_shortcode_regex(array('todo-t'));
            $text = preg_replace("/$pattern/", '', $text);
        }
        if (strpos($text, '[todo-f') !== false) {
            $pattern = self::get_shortcode_regex(array('todo-f'));
            $text = preg_replace("/$pattern/", '', $text);
        }
        if (strpos($text, '{bs-accord') !== false) {
            $pattern = self::get_shortcode_regex2(array('bs-accord'));
            $text = preg_replace("/$pattern/", '', $text);
        }
        if (strpos($text, '{bs-font') !== false) {
            $pattern = self::get_shortcode_regex2(array('bs-font'));
            $text = preg_replace("/$pattern/", '', $text);
        }
        if (strpos($text, '{bs-iframe') !== false) {
            $pattern = self::get_shortcode_regex2(array('bs-iframe'));
            $text = preg_replace("/$pattern/", '', $text);
        }
        if (strpos($text, '{bs-card') !== false) {
            $pattern = self::get_shortcode_regex2(array('bs-card'));
            $text = preg_replace("/$pattern/", '', $text);
        }
        if (strpos($text, '{bs-audio') !== false) {
            $pattern = self::get_shortcode_regex2(array('bs-audio'));
            $text = preg_replace("/$pattern/", '', $text);
        }

      }

               return $text;
}   


/* 置顶
     * Date:09/10/2021
     *
     * @access public
     * @return void
     */ 
     public static function sticky($archive, $select){
         $options = Options::alloc();
    if ($options->Sticky == '1'){
         $sticky_cids = $options->sticky_cids ? explode(',', strtr($options->sticky_cids, ' ', ',')) : ''; 
        if (!$sticky_cids) return;
        $db = \Typecho\Db::get();
        $paded = $archive->request->get('page', 1);
        $sticky_html = $options->sticky_html ? $options->sticky_html : "<span style='color:red'>[置顶] </span>";

        foreach($sticky_cids as $cid) {
          if ($cid && $sticky_post = $db->fetchRow($archive->select()->where('cid = ?', $cid))) {
              if ($paded == 1) {
                $sticky_post['sticky'] = $sticky_html;
                $archive->push($sticky_post); 
              }
              $select->where('table.contents.cid != ?', $cid);
          }
        }
    }
         
     }   
}
   
?>